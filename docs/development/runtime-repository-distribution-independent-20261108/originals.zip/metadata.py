import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107');P=pathlib.Path('D:/ChantaResearchGroup/pida-repository-profile-20261108/.pida-test-runtime-repository-20261108');R=pathlib.Path('D:/prpd-1108/runtime')
sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((R/'manifest.json').read_text());source='e9a1d31140bcff34e3c9ef0f82f4b3dbca0ddd68'
assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==m['source_commit']==source
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()
src=subprocess.check_output(['git','-C',str(S),'archive','--format=tar',source]);assert sha(src)==m['source']['source_archive_sha256'];assert sha((P/'windows/pida-core-0.8.18.tgz').read_bytes())==m['package']['sha256']
for key,path in [('managed_capabilities_generator_sha256','scripts/managed-host-capabilities.mjs'),('script_sha256','scripts/package-runtime.mjs'),('platform_lock_sha256','scripts/runtime-platform-lock.json')]:assert sha((S/path).read_bytes())==m['packaging'][key]
assert sha((R/'managed-host-capabilities.json').read_bytes())=='8f4bd65fe7a74ac6944059bc97158b13f98fd473b95240352cd2e0ff49d8e579';assert (E/'test/repository-profile.test.mjs').read_bytes()==(S/'test/repository-profile.test.mjs').read_bytes()
archives=[];records={}
for plat,name,digest in [('windows','pida-runtime-e9a1d31-win32-x64.tar.gz','ed17b770612ae05df9e732e32bc63736aa3eb6fb0af8ec6384ab3f7412422f58'),('linux','pida-runtime-e9a1d31-linux-x64.tar.gz','581c5a8dd82bfaf2bbe9009bd13f92a92787ace4e69b8cc74bad2bcebe3c314f')]:
 p=P/plat/name;assert sha(p.read_bytes())==digest;archives.append({'platform':plat,'archive':str(p),'sha256':digest,'bytes':p.stat().st_size})
 repo=json.loads((E/(plat+'-repository/repository-probe.json')).read_text());assert repo['status']=='PASS' and repo['exit_code']==0 and repo['source_commit']==source;assert repo['test_source_sha256']==sha((S/'test/repository-profile.test.mjs').read_bytes())
 retained=json.loads((E/(plat+'-retained.json')).read_text());assert retained['status']=='PASS' and len(retained['scenarios'])==4
 for v in retained['scenarios']:
  assert v['resume_same_ids'] and v['token_rotated'] and v['policy_mismatch_no_mutation']
  if v['persona']!='local':assert all(r['inclusion_events']>0 for r in v['records'])
  if v['persona']=='catalogue':assert v['catalogue_mismatch_no_mutation']
 records[plat]={'repository_cases':12,'repository_result':repo,'retained_stock_scenarios':4,'retained_native_jobs':sum(len(v['records']) for v in retained['scenarios'])}
win=json.loads((E/'windows-delta.json').read_text(encoding='utf-8-sig'));lin=json.loads((E/'linux-delta.json').read_text(encoding='utf-8-sig'));delta=[x for x in win['changes'] if x['path'].startswith('pida/dist/')];assert delta==[x for x in lin['changes'] if x['path'].startswith('pida/dist/')]
result={'status':'PASS','source':source,'probe_evidence_source':'083a1c11f574879697c54bb7b7a4d82921728ea6','source_archive_sha256':sha(src),'npm_archive_sha256':m['package']['sha256'],'sidecar_sha256':sha((R/'managed-host-capabilities.json').read_bytes()),'packaging':m['packaging'],'archives':archives,'compiled_deltas':delta,'records':records,'generator_source_review_sha256':'5799c15d99a62835a627541398594dd5712716dfbd2e15373b89581220b8407a','author_repository_probe_sha256':sha((E/'scripts/author-repository-original.mjs').read_bytes()),'reviewer_repository_probe_sha256':sha((E/'scripts/probe-repository.mjs').read_bytes()),'retained_stock_probe_sha256':sha((E/'scripts/probe-retained.mjs').read_bytes()),'reviewer_change':'Synthetic repository profile runtime identity replaced with actual verified artifact source+manifest; only external harness changes.','scope':'Scripted SDK usage is simulated; stock mode3 fresh/resume/readback separate. No GUI/real provider/account/user repository. Reference Python external.'}
(E/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['records','compiled_deltas']}))
