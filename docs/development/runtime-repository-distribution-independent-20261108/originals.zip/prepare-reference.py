import pathlib,json,hashlib,shutil
E=pathlib.Path(__file__).parent;origin=pathlib.Path('D:/pmcd-1108/reference-source');dest=pathlib.Path('D:/prpd-1108/reference-source')
lock=json.loads(pathlib.Path('D:/prpd-1108/runtime/pida/fixtures/vera-dispatch/local-reference-source-lock.json').read_text());dest.mkdir();files=[]
for name,digest in lock['runtime_files'].items():
 p=origin/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);files.append({'path':name,'sha256':digest})
(E/'reference-source-provision.json').write_text(json.dumps({'review_export':str(dest),'verified_files':files,'config_and_stores':'Fresh per scenario; no previous store copied.'},indent=2)+'\n');print(len(files))
