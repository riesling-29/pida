import test from 'node:test';
import assert from 'node:assert/strict';
import { Type } from 'typebox';
import { fauxProvider, fauxAssistantMessage as answer, fauxToolCall as call } from '@earendil-works/pi-ai/providers/faux';
import { PidaRuntime } from './dist/runtime.js';
const owner={id:'guard-review',permissions:['fixture:write']};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};

async function runCase(t, options={}) {
  const f=fauxProvider({tokensPerSecond:100000});
  let confirmations=0;
  const tool={name:'agent_join',description:'Synthetic trusted host test tool, not native join',parameters:Type.Object({}),permission:'fixture:write',effect:'idempotent',effectResult:()=>options.effectState??'applied',classifyResult:()=>({status:options.toolStatus??'completed',...(options.toolStatus==='failed'?{code:'SYNTHETIC_TOOL_FAILED'}:{})}),execute:async()=>({ok:true,effectState:'applied',join:{id:'model-visible-marker'},AGENT_JOIN_YIELDED:true}),
    ...(options.confirm===undefined?{}:{confirmRunYield:()=>{confirmations++;return options.confirm();}})};
  f.setResponses(options.responses??[answer(call('agent_join',{}),{stopReason:'toolUse'}),answer('')]);
  const runtime=new PidaRuntime({provider:()=>({provider:f.provider,modelId:f.getModel().id}),tools:[tool],maxProviderRetries:0,maxOutputRetries:0,maxRunMs:5000,...options.runtime,...(options.runtime?.workSurface?{workSurface:{replay:()=>undefined,prepare:()=>'',settle:()=>{},...options.runtime.workSurface}}:{})});
  t.after(()=>runtime.close());
  const {sessionId}=await runtime.createSession(owner);
  const result=await runtime.run(sessionId,owner,'Independent synthetic guard',undefined,options.signal);
  return {result,confirmations,runtime,sessionId,f};
}

test('tool name and model-visible marker alone cannot permit empty response',async t=>{
  const {result}=await runCase(t);assert.equal(result.status,'failed');assert.equal(result.code,'EMPTY_RESPONSE');assert.equal(result.text,'');
});
for (const [name,confirm] of [['false',()=>false],['throw',()=>{throw Error('no');}],['thenable',()=>Promise.resolve(true)],['truthy-object',()=>({ok:true})]])
  test(`host finalizer ${name} does not authorize empty result`,async t=>{const {result,confirmations}=await runCase(t,{confirm});assert.equal(result.code,'EMPTY_RESPONSE');assert.ok(confirmations>=1);});
test('not-applied effect cannot arm host finalizer',async t=>{const {result,confirmations}=await runCase(t,{effectState:'not_applied',confirm:()=>true});assert.equal(result.code,'EMPTY_RESPONSE');assert.equal(confirmations,0);});
test('unknown effect outranks host finalizer',async t=>{const {result,confirmations}=await runCase(t,{effectState:'unknown',confirm:()=>true});assert.equal(result.code,'EFFECT_STATE_UNKNOWN');assert.equal(confirmations,0);assert.equal(result.recovery.autoRetry,false);});
test('failed classified result outranks successful receipt',async t=>{const {result,confirmations}=await runCase(t,{toolStatus:'failed',confirm:()=>true});assert.equal(result.code,'SYNTHETIC_TOOL_FAILED');assert.equal(confirmations,0);});
test('provider failure cannot yield even after successful host handoff',async t=>{const {result}=await runCase(t,{confirm:()=>true,responses:[answer(call('agent_join',{}),{stopReason:'toolUse'}),()=>{throw Error('synthetic provider failure');}]});assert.equal(result.code,'PROVIDER_FAILED');});
test('normal nonempty text is not changed or replaced by yield code',async t=>{const {result,confirmations}=await runCase(t,{confirm:()=>true,responses:[answer(call('agent_join',{}),{stopReason:'toolUse'}),answer('Nonempty actual text')]});assert.equal(result.status,'completed');assert.equal(result.code,undefined);assert.equal(result.text,'Nonempty actual text');assert.equal(confirmations,0);});
test('a later cancelled work-surface completion cannot preserve yielded success',async t=>{
  const entered=deferred(),release=deferred(),controller=new AbortController();
  const pending=runCase(t,{confirm:()=>true,signal:controller.signal,runtime:{workSurface:{finish:async()=>{entered.resolve();await release.promise;}}}});
  await entered.promise;controller.abort();release.resolve();const {result}=await pending;
  assert.equal(result.status,'cancelled');assert.equal(result.code,'CANCELLED');assert.equal(result.text,'');
});
test('revision invalidation while work surface finishes denies yielded terminal record',async t=>{
  const entered=deferred(),release=deferred();let current=true;
  const pending=runCase(t,{confirm:()=>current,runtime:{workSurface:{finish:async()=>{entered.resolve();await release.promise;}}}});
  await entered.promise;current=false;release.resolve();const {result}=await pending;
  assert.equal(result.status,'failed');assert.equal(result.code,'AGENT_JOIN_YIELD_OBSOLETE');
});
