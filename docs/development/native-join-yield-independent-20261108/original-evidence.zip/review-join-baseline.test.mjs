import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fauxProvider, fauxAssistantMessage as answer, fauxToolCall as call } from '@earendil-works/pi-ai/providers/faux';
import { PidaRuntime } from './dist/runtime.js';
import { AgentSupervisor } from './dist/agent-supervisor.js';
import { createAgentTools } from './dist/agent-tools.js';

const evidence = 'D:/ChantaResearchGroup/pida-join-review-evidence-20261108';
mkdirSync(evidence, { recursive: true });
const owner = { id: 'independent-review', permissions: ['pida:agents', 'agent:delegate', 'agent:read'] };
async function until(fn) { for (let i=0; i<500; i++) { const v=await fn(); if(v)return v; await delay(10); } throw Error('review timeout'); }
for (const empty of [false, true]) test(`baseline trusted join with ${empty?'empty':'nonempty'} final text`, async t => {
  const directory=mkdtempSync(join(evidence, empty?'empty-':'nonempty-'));
  let s,parent,child,modelRequests=0;
  const createRuntime=profile=>{
    const f=fauxProvider({tokensPerSecond:100000});
    f.setResponses(profile.id===parent.id ? [
      ()=>{modelRequests++; return answer(call('agent_delegate',{agentId:child.id,input:'synthetic child'}),{stopReason:'toolUse'});},
      ()=>{modelRequests++; return answer(call('agent_join',{required:[s.jobs(child.id,owner)[0].id]}),{stopReason:'toolUse'});},
      ()=>{modelRequests++; return answer(empty?'':'Registered child batch.');},
      ()=>{modelRequests++; return answer('Synthetic final continuation.');}
    ]:[async()=>{modelRequests++;await delay(500);return answer('Synthetic child result.');}]);
    return new PidaRuntime({storageDir:join(directory,profile.id),provider:()=>({provider:f.provider,modelId:f.getModel().id}),tools:createAgentTools(s,profile.id),maxRunMs:5000});
  };
  s=await AgentSupervisor.open({directory,maxConcurrent:2,workspaceKey:p=>p.id,resolvePrincipal:()=>owner,createRuntime});
  t.after(()=>s.close());
  parent=s.register(owner,{name:'parent'});child=s.register(owner,{name:'child'});
  const org=s.createOrganization(owner,{requestId:'synthetic-baseline',goal:'Delegate then join',agentId:parent.id,participants:[parent.id,child.id],criterionIds:[]});
  s.start();
  const outcome=await until(async()=>{const v=await s.getOrganization(org.id,owner);return v.organization.status!=='active' && v;});
  await until(()=>!s.jobs(child.id,owner).some(j=>['queued','running'].includes(j.status)));
  const parentJobs=s.jobs(parent.id,owner), childJobs=s.jobs(child.id,owner);
  const record={empty,modelRequests,organization:outcome.organization.status,joins:outcome.joins.map(j=>({status:j.status,code:j.code,continuationJobId:j.continuationJobId})),parentJobs:parentJobs.map(j=>({status:j.status,code:j.code,runId:j.runId,text:j.result?.text,resultStatus:j.result?.status})),childJobs:childJobs.map(j=>({status:j.status,code:j.code}))};
  writeFileSync(join(evidence,empty?'baseline-empty.json':'baseline-nonempty.json'),JSON.stringify(record,null,2));
  if(empty) {
    assert.equal(parentJobs.length,1);assert.equal(parentJobs[0].status,'failed');assert.equal(parentJobs[0].code,'EMPTY_RESPONSE');
    assert.equal(parentJobs[0].result.text,'');assert.equal(outcome.joins[0].status,'blocked');assert.equal(outcome.joins[0].code,'JOIN_REQUIRED_RESULT_UNAVAILABLE');
  } else { assert.equal(parentJobs.length,2);assert.equal(outcome.joins[0].status,'ready');assert.equal(parentJobs[1].status,'completed'); }
  assert.equal(childJobs[0].status,'completed');
});
