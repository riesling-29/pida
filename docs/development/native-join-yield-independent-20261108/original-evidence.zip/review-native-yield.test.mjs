import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fauxProvider, fauxAssistantMessage as answer, fauxToolCall as call } from '@earendil-works/pi-ai/providers/faux';
import { PidaRuntime } from './dist/runtime.js';
import { AgentSupervisor } from './dist/agent-supervisor.js';
import { createAgentTools } from './dist/agent-tools.js';
import { validateObservationBundle } from './dist/integration-contract.js';
const evidence='D:/ChantaResearchGroup/pida-join-review-evidence-20261108';mkdirSync(evidence,{recursive:true});
const owner={id:'native-review',permissions:['pida:agents','agent:delegate','agent:read']};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
async function until(fn){for(let n=0;n<600;n++){const v=await fn();if(v)return v;await delay(10);}throw Error('native review timeout');}
async function fixture(t,{childDelay=450,childFails=false,holdFinal=false,finalText=''}={}){
  const directory=mkdtempSync(join(evidence,'native-')),joined=deferred(),finishParent=deferred();
  let s,parent,child,receipt,context,joinTool,requests=0;
  const createRuntime=profile=>{
    const f=fauxProvider({tokensPerSecond:100000});
    const tools=createAgentTools(s,profile.id);
    if(profile.id===parent.id){
      joinTool=tools.find(x=>x.name==='agent_join');const execute=joinTool.execute;
      joinTool.execute=async(args,ctx)=>{const value=await execute(args,ctx);receipt=value;context=ctx;joined.resolve();return value;};
      f.setResponses([
        ()=>{requests++;return answer(call('agent_delegate',{agentId:child.id,input:'child synthetic task'}),{stopReason:'toolUse'});},
        ()=>{requests++;return answer(call('agent_join',{required:[s.jobs(child.id,owner)[0].id]}),{stopReason:'toolUse'});},
        async()=>{requests++;if(holdFinal)await finishParent.promise;return answer(finalText);},
        ()=>{requests++;return answer('Actual synthetic continuation text');}
      ]);
    }else f.setResponses([async()=>{requests++;await delay(childDelay);return answer(childFails?'':'Actual synthetic child text');}]);
    return new PidaRuntime({storageDir:join(directory,profile.id),provider:()=>({provider:f.provider,modelId:f.getModel().id}),tools,maxRunMs:5000});
  };
  const options={directory,maxConcurrent:2,workspaceKey:p=>p.id,resolvePrincipal:()=>owner,createRuntime};
  s=await AgentSupervisor.open(options);t.after(async()=>{finishParent.resolve();await s.close();});
  parent=s.register(owner,{name:'parent'});child=s.register(owner,{name:'child'});
  const org=s.createOrganization(owner,{requestId:'review-native-yield',goal:'Synthetic delegate/join',agentId:parent.id,participants:[parent.id,child.id],criterionIds:[]});s.start();await joined.promise;
  return {get s(){return s;},set s(v){s=v;},parent,child,org,directory,options,finishParent,get receipt(){return receipt;},get context(){return context;},get joinTool(){return joinTool;},get requests(){return requests;}};
}
for(const childDelay of [0,450])test(`empty native join completes one continuation with child delay ${childDelay}`,async t=>{
  const f=await fixture(t,{childDelay});
  const outcome=await until(async()=>{const o=await f.s.getOrganization(f.org.id,owner);return o.organization.status!=='active'&&o;});
  const jobs=f.s.jobs(f.parent.id,owner);assert.equal(jobs.length,2);assert.equal(jobs[0].status,'completed');assert.equal(jobs[0].result.status,'completed');assert.equal(jobs[0].code,'AGENT_JOIN_YIELDED');assert.equal(jobs[0].result.text,'');
  assert.equal(jobs[1].status,'completed');assert.equal(jobs[1].result.text,'Actual synthetic continuation text');assert.equal(outcome.joins[0].status,'ready');assert.equal(outcome.currentAcceptance,'UNKNOWN');assert.equal(f.requests,5);
  const runtime=await f.s.getRuntime(f.parent.id,owner),bundle=runtime.exportRun(jobs[0].sessionId,jobs[0].runId,owner);
  assert.equal(validateObservationBundle(bundle).valid,true);const terminal=bundle.events.filter(e=>e.activity==='run_finished');assert.equal(terminal.length,1);assert.equal(terminal[0].payload.status,'completed');assert.equal(terminal[0].payload.code,'AGENT_JOIN_YIELDED');
  await f.s.close();f.s=await AgentSupervisor.open({...f.options,createRuntime:()=>{throw Error('must not replay');}});f.s.start();await delay(80);
  assert.equal(f.s.jobs(f.parent.id,owner).length,2);assert.equal((await f.s.getOrganization(f.org.id,owner)).joins[0].continuationJobId,jobs[1].id);
});
test('failed required child still blocks continuation after parent yields',async t=>{
  const f=await fixture(t,{childFails:true});const outcome=await until(async()=>{const o=await f.s.getOrganization(f.org.id,owner);return o.organization.status!=='active'&&o;});
  assert.equal(f.s.jobs(f.parent.id,owner).length,1);assert.equal(f.s.jobs(f.parent.id,owner)[0].code,'AGENT_JOIN_YIELDED');assert.equal(outcome.organization.status,'failed');assert.equal(outcome.joins[0].code,'JOIN_REQUIRED_RESULT_UNAVAILABLE');assert.equal(outcome.joins[0].continuationJobId,undefined);
});
test('host handoff proof rejects foreign run/session/owner/job/revision, and cancelled join',async t=>{
  const f=await fixture(t,{holdFinal:true});
  const proof={agentId:f.parent.id,sessionId:f.context.sessionId,runId:f.context.runId,joinId:f.receipt.join.id,revision:f.receipt.join.revision};
  const job=f.context.taskId;assert.equal(f.s.confirmJoinYield(job,owner,proof),true);assert.equal(f.joinTool.confirmRunYield(f.receipt,f.context),true);
  for(const changed of [{runId:'foreign'},{sessionId:'foreign'},{agentId:f.child.id},{joinId:'foreign'},{revision:99}])assert.equal(f.s.confirmJoinYield(job,owner,{...proof,...changed}),false);
  assert.equal(f.s.confirmJoinYield('foreign',owner,proof),false);assert.equal(f.s.confirmJoinYield(job,{id:'foreign',permissions:owner.permissions},proof),false);assert.equal(f.s.confirmJoinYield(job,{...owner,permissions:[]},proof),false);
  assert.equal(f.joinTool.confirmRunYield({...f.receipt,join:{...f.receipt.join,parentJobId:'foreign'}},f.context),false);
  await f.s.cancelJoin(f.receipt.join.id,owner,1);assert.equal(f.s.confirmJoinYield(job,owner,proof),false);f.finishParent.resolve();
  await until(()=>f.s.jobs(f.parent.id,owner)[0].status!=='running');assert.notEqual(f.s.jobs(f.parent.id,owner)[0].code,'AGENT_JOIN_YIELDED');assert.equal(f.s.jobs(f.parent.id,owner).length,1);
});
test('close before native terminal persistence stays interrupted and cannot replay a continuation',async t=>{
  const f=await fixture(t,{holdFinal:true,childDelay:450});
  const initial=f.s.jobs(f.parent.id,owner)[0].id;
  const closing=f.s.close();f.finishParent.resolve();await closing;
  f.s=await AgentSupervisor.open({...f.options,createRuntime:()=>{throw Error('no model replay');}});f.s.start();await delay(80);
  assert.equal(f.s.getJob(initial,owner).status,'interrupted');assert.notEqual(f.s.getJob(initial,owner).code,'AGENT_JOIN_YIELDED');
  const after=await f.s.getOrganization(f.org.id,owner);assert.equal(f.s.jobs(f.parent.id,owner).length,1);assert.equal(after.joins[0].continuationJobId,undefined);
});
