import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root=resolve(process.argv[2]);
const { connectObservationTui }=await import(pathToFileURL(join(root,'examples/schumpeter-observation-tui.mjs')));
const token='synthetic-review-private-credential-'.repeat(2), hostId='review-host';
let sinkCalls=0, sourceCalls=[], mode='redirect';
const sink=createServer((q,r)=>{sinkCalls++;r.writeHead(500);r.end();}); await new Promise(r=>sink.listen(0,'127.0.0.1',r));
const server=createServer((q,r)=>{sourceCalls.push({path:q.url,method:q.method});assert.equal(q.headers.authorization,`Bearer ${token}`);
 if(mode==='redirect'){r.writeHead(302,{Location:`http://127.0.0.1:${sink.address().port}/v1/collaboration/capabilities`});r.end();return;}
 r.setHeader('Content-Type','application/json');
 if(q.url==='/v1/collaboration/capabilities')r.end(JSON.stringify({schema_version:mode==='bad-schema'?'wrong':'pida.collaboration.capabilities/1',host_id:mode==='wrong-host'?'foreign':hostId,enabled:mode!=='disabled'}));
 else r.end('{}');
});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const env={PIDA_TUI_BASE_URL:`http://127.0.0.1:${server.address().port}`,PIDA_TUI_TOKEN:token,PIDA_TUI_HOST_ID:hostId};
const result={source:'8bf35c47091af4623ab88d4c666628f0d2657601',checks:[]};
try {
 await assert.rejects(connectObservationTui(env));assert.equal(sinkCalls,0);assert.equal(sourceCalls.length,1);result.checks.push('redirect rejected with zero target requests');
 for(mode of ['bad-schema','wrong-host','disabled']){sourceCalls=[];await assert.rejects(connectObservationTui(env),/TUI_HOST_MISMATCH/);assert.equal(sourceCalls.length,1);result.checks.push(mode+' fails before info/UI');}
 for(const url of ['https://127.0.0.1:1234','http://localhost:1234','http://192.0.2.1:1234','http://127.0.0.1:1234/v1','http://127.0.0.1:1234?token=x','http://user:password@127.0.0.1:1234','http://127.0.0.1:1234#x']) await assert.rejects(connectObservationTui({...env,PIDA_TUI_BASE_URL:url}),/TUI_ENDPOINT_INVALID/);
 result.checks.push('seven invalid endpoint forms rejected before fetch');
 mode='ok';sourceCalls=[];const connection=await connectObservationTui(env);assert.equal(sourceCalls.length,2);
 for(const operation of [()=>connection.client.createAgent({name:'forbidden'}),()=>connection.client.createOrganization({}),()=>connection.client.admitOrganization({}),()=>connection.client.receiveCollaboration({}),()=>connection.client.cancelOrganization('x')])await assert.rejects(operation(),{code:'HOST_OBSERVATION_ONLY_USE_SCHUMPETER_TASK_CONTROLS',status:403});
 assert.equal(sourceCalls.length,2);result.checks.push('five mutations rejected with zero write HTTP requests');
 connection.close();await assert.rejects(connection.client.getInfo());assert.equal(sourceCalls.length,2);result.checks.push('closed client aborts future read without stopping server');
 const child=spawnSync(process.execPath,[join(root,'examples/schumpeter-observation-tui.mjs'),'--forbidden-argument'],{env:{...process.env,...env},encoding:'utf8',windowsHide:true,timeout:3000});
 assert.equal(child.status,1);assert.equal(child.stdout,'');assert.doesNotMatch(child.stderr,new RegExp(token));assert.ok(!child.stderr.includes(env.PIDA_TUI_BASE_URL));assert.match(child.stderr,/PIDA_OBSERVATION_TUI_FAILED/);result.checks.push('nonprivate-argument entrypoint failure redacts URL/token');
 writeFileSync(new URL('network-fixed-probe-result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
}finally{await new Promise(r=>server.close(r));await new Promise(r=>sink.close(r));}
