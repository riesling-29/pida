import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107');P=pathlib.Path('D:/ChantaResearchGroup/pida/.pida-test-runtime-distribution-path-20261108')
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads(pathlib.Path('D:/pwr-dist-1108/runtime/manifest.json').read_text())
assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==m['source_commit']=='b7f7d523c6fede56d508575a6bb78afa343e5566'
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()
source_bytes=subprocess.check_output(['git','-C',str(S),'archive','--format=tar',m['source_commit']]);assert sha(source_bytes)==m['source']['source_archive_sha256']
assert sha((P/'windows/pida-core-0.8.18.tgz').read_bytes())==m['package']['sha256']
for key,path in [('script_sha256','scripts/package-runtime.mjs'),('platform_lock_sha256','scripts/runtime-platform-lock.json')]:assert sha((S/path).read_bytes())==m['packaging'][key]
archives=[]
for plat,name,digest in [('windows','pida-runtime-b7f7d52-win32-x64.tar.gz','b8761c8d363311228d8b808f76546720673694165277d14178662af0a38ef3f0'),('linux','pida-runtime-b7f7d52-linux-x64.tar.gz','e9090be1cf9cd632aa214ae56399358ca83488129cd56d6c467ee373592f0d67')]:
 p=P/plat/name;assert sha(p.read_bytes())==digest;archives.append({'platform':plat,'archive':str(p),'sha256':digest,'bytes':p.stat().st_size})
 delta=json.loads((E/(plat+'-delta.json')).read_text(encoding='utf-8-sig'));compiled=[x for x in delta['changes'] if x['path'].startswith('pida/dist/')];assert compiled==[{'path':'pida/dist/workbench.js','sha256':'043a0eeb21907103d07e70907653e59544f162ffcc68c68495b96c0f118b99a9'}]
 probe=json.loads((E/(plat+'-packaged-path.json')).read_text());assert probe['status']=='PASS' and probe['toolInvocations']==61
 for kind in ['clean','reference']:
  f=P/plat/(kind+'-probe.json');data=json.loads(f.read_text());assert data['status']=='PASS' and data['terminal_event'] and data['resume_same_job'] and data['transport_token_rotated'];(E/('author-'+plat+'-'+kind+'-probe.json')).write_bytes(f.read_bytes())
result={'status':'PASS','source':m['source_commit'],'source_archive_sha256':sha(source_bytes),'package_sha256':m['package']['sha256'],'packaging':m['packaging'],'archives':archives,'source_review_report_sha256':'6246f3e7d74f3628585b4cc7dbe4a96f8a5f8bcbe10529976a8461f2cde2741e','source_workbench_sha256':sha((S/'src/workbench.ts').read_bytes()),'compiled_workbench_sha256':sha((S/'dist/workbench.js').read_bytes()),'only_compiled_delta':'dist/workbench.js','independent_packaged_probe_sha256':sha((E/'probe.mjs').read_bytes()),'author_stock_base_and_reference_results':'copied exact; inspected, not independently rerun in this delta','independent_probe_scope':'direct packaged public Pi-workbench tools, state reopen and effect/evidence callbacks; zero provider calls'}
(E/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
