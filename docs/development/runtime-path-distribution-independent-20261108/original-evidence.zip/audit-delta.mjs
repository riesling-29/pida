﻿import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [root,old,source,out]=process.argv.slice(2).map(p=>resolve(p));
const sha=b=>createHash('sha256').update(b).digest('hex');
const m=JSON.parse(readFileSync(join(root,'manifest.json'))),o=JSON.parse(readFileSync(join(old,'manifest.json')));
assert.equal(m.source_commit,'b7f7d523c6fede56d508575a6bb78afa343e5566');
const vendor=f=>f.path.startsWith('node/')||f.path.startsWith('git/')||f.path.startsWith('pida/node_modules/');
assert.deepEqual(m.files.filter(vendor),o.files.filter(vendor));
assert.deepEqual(m.dependencies,o.dependencies);assert.deepEqual(m.license_files,o.license_files);assert.deepEqual(m.node,o.node);
assert.equal(m.source.dependency_lock_sha256,o.source.dependency_lock_sha256);
assert.equal(m.built_with.node,process.version);assert.equal(m.built_with.abi.modules,process.versions.modules);
let dist=0,own=0;
for(const f of m.files.filter(f=>f.path.startsWith('pida/')&&!vendor(f))){
 const p=f.path.slice(5),data=readFileSync(join(root,f.path));
 assert.equal(sha(data),sha(readFileSync(join(source,p))),p);
 if(p.startsWith('dist/'))dist++;else own++;
}
for(const f of m.license_files)assert.ok(readFileSync(join(root,f)).length);
for(const p of ['pida/node_modules/typescript','pida/node_modules/playwright','node/node_modules/npm','npm-cache','build-tools'])assert.equal(existsSync(join(root,p)),false);
const secretNames=m.files.filter(f=>/(?:^|\/)(?:\.env|\.npmrc|credentials?\.json|auth\.json|id_rsa|id_ed25519)$/.test(f.path));assert.deepEqual(secretNames,[]);
const module=await import(pathToFileURL(join(root,'pida/dist/agent-tui.js')));assert.equal(typeof module.runAgentTerminal,'function');
const changes=m.files.filter(f=>{const before=o.files.find(x=>x.path===f.path);return !before||before.sha256!==f.sha256;}).map(f=>({path:f.path,sha256:f.sha256}));
const result={status:'PASS',platform:process.platform,source:m.source_commit,manifest_sha256:sha(readFileSync(join(root,'manifest.json'))),package:m.package,packaging:m.packaging,vendor_files_byte_mode_identical:m.files.filter(vendor).length,dependencies_identical:m.dependencies.length,license_files_identical:m.license_files.length,rebuilt_dist_files:dist,source_package_files:own,observation_wrapper_sha256:sha(readFileSync(join(root,'pida/examples/schumpeter-observation-tui.mjs'))),observation_module_loaded:true,credential_filename_findings:secretNames,changes};
writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,changes:changes.length}));

