import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,symlinkSync,linkSync,unlinkSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const [moduleRoot,base,mode,output]=process.argv.slice(2);
const {PidaWorkbench,workbenchPermissions}=await import(pathToFileURL(join(resolve(moduleRoot),'dist/workbench.js')));
const sha=s=>createHash('sha256').update(s).digest('hex'), principal={id:'review-only-owner',permissions:workbenchPermissions};
const directory=mkdtempSync(join(resolve(base),'case-')),work=new PidaWorkbench(join(directory,'workbench'));
const tools=work.tools(),signal=new AbortController().signal,records=[];
const nestedExpected=mode!=='windows-baseline';
const invoke=async(name,args)=>{const tool=tools.find(t=>t.name===name);const value=await tool.execute(args,{principal,signal,sessionId:'review-session',runId:'review-run'});let evidence;try{evidence=tool.evidence?.(value);}catch(e){evidence={capture_error:e.message};}const result={name,args,value,effect:tool.effect,effectState:tool.effectResult?.(value),classification:tool.classifyResult?.(value,args),evidence};records.push(result);return result;};
function artifact(record,path,content){const a=record.evidence.changed.find(a=>a.path===path);assert.ok(a,path);const hash=sha(content);assert.equal(a.sha256,hash);assert.equal(a.bytes,Buffer.byteLength(content));assert.equal(a.id,sha(JSON.stringify({hash,path})));assert.ok(!a.path.includes('\\'));return a;}
try{
 const initial='{"synthetic":"review-only","value":17}\n';
 const path='artifacts/deep folder/review.json';
 const nested=await invoke('workspace_write',{path,content:initial});
 assert.equal(nested.value.ok,nestedExpected,JSON.stringify(nested.value));
 if(!nestedExpected){assert.equal(nested.value.error,'INVALID_PATH');assert.equal(nested.effectState,'not_applied');assert.deepEqual(nested.evidence.changed,[]);}
 else{assert.equal(nested.effectState,'applied');assert.equal(nested.classification.status,'completed');artifact(nested,path,initial);}
 // Direct method always succeeds, including on the failing packaged baseline.
 await work.write(principal,path,initial);assert.equal((await work.read(principal,path)).content,initial);
 const read=await invoke('workspace_read',{path});assert.equal(read.value.ok,nestedExpected);if(nestedExpected){assert.match(read.value.content,/review-only/);assert.deepEqual(read.evidence.changed,[]);assert.equal(read.effect,'read');}
 const edit=await invoke('workspace_edit',{path,edits:[{oldText:'17',newText:'23'}]});assert.equal(edit.value.ok,nestedExpected);
 const final=nestedExpected?initial.replace('17','23'):initial;assert.equal((await work.read(principal,path)).content,final);
 if(nestedExpected){assert.equal(edit.effectState,'applied');artifact(edit,path,final);}
 for(const p of ['flat.json','files-with-dashes/child_name.txt','spaces here/nested file.txt']){
  const result=await invoke('workspace_write',{path:p,content:'fresh-fixture\n'});assert.equal(result.value.ok,!p.includes('/')||nestedExpected);
  if(result.value.ok){assert.equal((await work.read(principal,p)).content,'fresh-fixture\n');artifact(result,p,'fresh-fixture\n');}
 }
 const flatRead=await invoke('workspace_read',{path:'flat.json'});assert.equal(flatRead.value.ok,true);
 const flatEdit=await invoke('workspace_edit',{path:'flat.json',edits:[{oldText:'fresh-fixture',newText:'flat-updated'}]});assert.equal(flatEdit.value.ok,true);assert.equal((await work.read(principal,'flat.json')).content,'flat-updated\n');
 const before=await work.status(principal);
 const invalid=['../escape.txt','a/../../escape.txt','a/../escape.txt','./flat.json','/absolute.txt','C:/drive.txt','C:drive.txt','C:\\drive.txt','\\\\server\\share\\file','a\\b.txt','a//b.txt','a/./b.txt','.env','a/.git/config','a\u0000b',''];
 for(const path of invalid)for(const name of ['workspace_read','workspace_write','workspace_edit']){
  const r=await invoke(name,{path,content:'must-not-write',edits:[{oldText:'review',newText:'changed'}]});assert.equal(r.value.ok,false,JSON.stringify({name,path}));assert.equal(r.value.error,'INVALID_PATH');assert.equal(r.effectState,'not_applied');assert.deepEqual(r.evidence.changed,[]);
 }
 assert.deepEqual(await work.status(principal),before);
 await assert.rejects(tools.find(t=>t.name==='workspace_write').execute({path:'denied/file',content:'no'},{principal:{id:principal.id,permissions:['workbench:read']},signal}),/FORBIDDEN/);
 const other={id:'review-other',permissions:workbenchPermissions};assert.deepEqual((await work.status(other)).files,[]);
 const root=join(directory,'workbench',sha(principal.id),'files'),outside=join(directory,'outside');mkdirSync(outside);const sentinel=join(outside,'sentinel.txt');writeFileSync(sentinel,'outside-untouched');
 const junction=join(root,'escape');symlinkSync(outside,junction,process.platform==='win32'?'junction':'dir');
 for(const name of ['workspace_read','workspace_write','workspace_edit']){const r=await invoke(name,{path:'escape/sentinel.txt',content:'bad',edits:[{oldText:'outside',newText:'bad'}]});assert.equal(r.value.ok,false);assert.equal(r.value.error,'UNSAFE_FILE');}
 assert.equal(readFileSync(sentinel,'utf8'),'outside-untouched');unlinkSync(junction);
 const hard=join(root,'hard.txt');linkSync(sentinel,hard);const hardResult=await invoke('workspace_write',{path:'hard.txt',content:'bad'});assert.equal(hardResult.value.ok,false);assert.equal(hardResult.value.error,'UNSAFE_FILE');unlinkSync(hard);assert.equal(readFileSync(sentinel,'utf8'),'outside-untouched');
 const dangling=join(root,'dangling');symlinkSync(join(directory,'does-not-exist'),dangling,process.platform==='win32'?'junction':'dir');const danglingResult=await invoke('workspace_write',{path:'dangling/new.txt',content:'bad'});assert.equal(danglingResult.value.ok,false);assert.equal(danglingResult.value.error,'UNSAFE_FILE');unlinkSync(dangling);assert.equal(existsSync(join(directory,'does-not-exist')),false);
 const reopened=new PidaWorkbench(join(directory,'workbench'));assert.equal((await reopened.read(principal,path)).content,final);assert.deepEqual(await reopened.status(principal),await work.status(principal));
 writeFileSync(output,JSON.stringify({status:'PASS',mode,platform:process.platform,moduleRoot:resolve(moduleRoot),freshDirectory:directory,nestedExpected,toolInvocations:records.length,negativePathInvocations:invalid.length*3,linkGuards:['directory-link','hardlink','dangling-directory-link'],providerCalls:0,records},null,2)+'\n');console.log(JSON.stringify({status:'PASS',mode,platform:process.platform,toolInvocations:records.length,output}));
}catch(e){writeFileSync(output,JSON.stringify({status:'FAIL',mode,platform:process.platform,message:e.message,stack:e.stack,records},null,2)+'\n');throw e;}
