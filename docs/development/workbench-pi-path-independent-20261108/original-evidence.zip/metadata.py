import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107');B=pathlib.Path('D:/pdrv-20261108/runtime/pida')
sha=lambda b:hashlib.sha256(b).hexdigest()
revision=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip();assert revision=='b7f7d523c6fede56d508575a6bb78afa343e5566'
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()
delta=[]
for p in (S/'dist').rglob('*'):
 if p.is_file() and p.read_bytes()!=(B/'dist'/p.relative_to(S/'dist')).read_bytes():delta.append(p.relative_to(S).as_posix())
assert delta==['dist/workbench.js'],delta
linux_compiled=subprocess.check_output(['wsl','-d','Ubuntu','--','cat','/var/tmp/pida-workbench-path-review-20261108/fixed-module/dist/workbench.js'])
assert linux_compiled==(S/'dist/workbench.js').read_bytes()
records={label:json.loads((E/(label+'.json')).read_text()) for label in ['windows-baseline','linux-baseline','windows-fixed','linux-fixed']}
assert all(v['status']=='PASS' for v in records.values())
for left,right in zip(records['windows-fixed']['records'],records['linux-fixed']['records']):
 assert left['name']==right['name'] and left['args']==right['args']
 if left.get('evidence',{}).get('changed'):
  assert left['evidence']['changed']==right['evidence']['changed']
result={'status':'PASS','source':revision,'baseline_source':'2b787fd4c234747da22726ec03a3e4c6619ae95f','source_sha256':sha((S/'src/workbench.ts').read_bytes()),'compiled_sha256':sha((S/'dist/workbench.js').read_bytes()),'compiled_delta':delta,'independent_probe_sha256':sha((E/'probe.mjs').read_bytes()),'fixed_cross_platform_artifact_identities_identical':True,'runs':{k:{f:v[f] for f in ['platform','moduleRoot','freshDirectory','toolInvocations','negativePathInvocations','nestedExpected','linkGuards','providerCalls']} for k,v in records.items()},'scope':'Source-only build and direct public tool callbacks/evidence; no new distribution or live runtime/provider/consumer gate.'}
(E/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
