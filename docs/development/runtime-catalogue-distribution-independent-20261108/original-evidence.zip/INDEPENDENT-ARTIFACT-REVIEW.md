# Independent managed policy/catalogue artifact review — 2026-11-08

Reviewer `/root/pida_windows_review`. Exact artifact source
`0f1b895d72d2f05a7c4fa21a2c9a5070aad71d8f`; author handoff freeze
`71a7e17fd7d7096de57335d978dad724c299faaf`. Generator source review SHA
`7769835cb8e545137a249aff0e2262413463da26b4f935e2d0b4b638b5bc697a`
is retained separately, including its corrected initial findings. This unit
reviews actual archives and packaged execution, not just generator source.

## Immutable identity

| Platform | Archive SHA-256 | Manifest SHA-256 | Files |
| --- | --- | --- | --- |
| Windows x64 | `550afde0caff9e0ae2a7e3acadb82c6ef64d8ceb967f85bec44d68a125be15e8` | `0c3a5c551520deabe9504dbcbce9591fa740638ce01f3b42244e01f0ae6845f3` | 16108 |
| Linux x64 | `040733b5aa20e976705996e3af20f704357f98ddaed6b6dbc0e6ab1ae38fda4c` | `6440e590ccf0a56da344571647c336beb350d0fca5b55523930e669d0830480a` | 15782 |

Both sidecars have SHA-256
`862dea17a42aa001e9e20c810f36a97d3b577d985af908e98d19b676df701973`.
Shared npm archive SHA is
`fba076093248cd2a0505b0416db9ef9ffbc31507eadba49270b074eb59ca9c25`.
Independent regenerated source archive matches
`3a86a4003a8494276e0547510063b222020fd6e7ef21a8776cc27a75d9a8482f`.
`metadata.json` records full delivery paths, sizes, source/package/generator/
builder/lock hashes and both platforms' exact compiled deltas.

## Independent closure verification

- Rehashed both archives and extracted normally into reviewer-owned
  `D:/pmcd-1108/runtime` and
  `/var/tmp/pida-managed-dist-review-20261108/runtime`. Pinned full-tree checks
  passed before and after execution. The corrected verifier then validated the
  regular inventoried sidecar, full source provenance, exact golden/profile
  tuples and required regular declared modules. Separate Linux byte/mode/extra
  file comparison also found zero differences.
- All152 compiled files and434 other own-package files match the exact source
  and independent build from the generator review. Nine compiled files differ
  from accepted b7/D: agent-supervisor JS/declaration, new execution-policy
  JS/declaration, index JS/declaration, workspace JS/declaration, and
  provider-settings.d.ts. The last is only inferred property order; source and
  executable provider-settings.js are unchanged. It is included in the delta,
  not omitted. No runtime source/examples/fixture content changed after the
  accepted policy9cbecfd and corrected catalogue127611e sources.
- Complete vendor inventories remain byte/mode-identical to accepted D:
  Windows15521 and Linux15195 entries. All125 dependency records, dependency
  lock, official Node identity and license inventories are unchanged. Earlier
  official Node/Git/library provenance is reused by exact identity. All retained
  notice files exist/nonempty (Windows165/Linux124). Known credential filenames
  and checked development/npm/cache locations are absent; this bounded check
  is not a general secret-scan certification.
- The packaged observation module loads with standalone bundled Node24.18.0.
  Its wrapper hash remains
  `f71d8f4f678fc052403de02dfe05981240d893af2624f51ae48f3cdb2e61d72c`.

The sidecar declares ready `pida.local-host/2`, workspace
`pida.local-host.workspace/2`, admission capabilities/2 and catalogue/1, with
closed smoke/1 and work/1 policy objects. The tested startup/resume uses those
packaged implementations. An unverified detached declaration is not authority.

## Independently executed packaged scenarios

The inspected author external probe was copied into this evidence directory
and strengthened to require nonempty reference inclusion events, exact
agentInstanceId binding and actual selected catalogue profile. Original and
reviewer probe hashes are both in metadata; product package bytes were unchanged.

| Scenario, independently run on each OS | Observed result |
| --- | --- |
| Default smoke/1, local Persona | Exact ready2/capabilities2/policy; native job completes; same IDs on resume |
| Explicit work/1, local Persona | Exact work tuple; native job completes; work policy retained on selector-free resume |
| Work/1, global external reference | Nonempty current-provider source receipts bind exact native lineage; same IDs on resume |
| Work/1, two-profile catalogue | Both profile-a and profile-b selected; distinct expected personas and lineage receipts; same source/IDs on resume |

Each platform ran four scenarios and five native owner-created jobs. Reference
scenarios produced six context inclusion events per platform. Actual private
ready protocol/persona/policy and authenticated admission readback matched the
sidecar. Organization deadlines matched the selected policy; repair attempts
remain zero. Every job exported a terminal `run_finished` event. All three
reference jobs per platform had nonempty receipts matching persona, task,
attempt, organization and agent IDs with `current-provider-check` authorization.

Every scenario closed and resumed with the same native job/attempt/source IDs
and a rotated transport token. Explicit wrong-policy resume was rejected with
`HOST_RESUME_MISMATCH`; changed catalogue identity was likewise rejected.
All workspace file bytes were unchanged across those rejected resumes. This
probe's mismatch snapshot covers file bytes, not directory metadata; it is not
described as a broader filesystem-transaction proof.

Both runs used explicit bundled Node/Git, private HOME and disabled global/system
Git config. Reference export preparation independently verified all nine locked
producer files and copied no prior config/store. Each scenario initialized new
synthetic configs/stores through explicit external Python3.11.9 on Windows and
3.14.4 on Linux with `-I -B`. The producer is f6edd02, not canonical user memory.
See `reference-source-provision.json` and both `*-runtime-probe.json` files.

The probe uses actual packaged stock mock hosts; it is not a scripted product
test mode or a multi-agent-model scenario. Native owner APIs create the jobs;
external admission authorization success is not claimed. No external provider
or account/auth call occurred. Synthetic local host/policy transport credentials
were used and excluded from results. Historical `credentials_used:false` means
provider credentials, not absence of local transport authentication.

## Scope and remaining gates

No old BB/2b/D workspace, cache, real case, request counter or deployment was
modified. Author evidence is retained by the pinned handoff; the execution and
closure observations above were independently repeated in this reviewer context.
Previously accepted runtime/join and guard suites were not gratuitously rerun.

Actual environment remains Windows10.0.26200 and WSL Ubuntu26.04.1 x64 with
glibc2.43, official standalone Node24.18.0/ABI137 and the accepted Git closures.
Selected Linux Git still needs GLIBC_2.38 symbols plus system shell/libc/loader;
this does not prove all distributions at that floor. Short app-owned Windows
paths remain required. Native clipboard/GUI, Electron ABI, remote Git, musl,
ARM64 and older Linux were not newly accepted.

Parent frozen Python service, trusted consumer/cache binding, live ready
readback in the actual parent assembly, renderer restrictions, desktop UX,
canonical memory/grant lifecycle and real-model behavior remain separate gates.
Empty criteria mean native completion is not native artifact/task acceptance.
Profile timing adequacy and future model costs are unknown. No public
redistribution-rights certification or cache promotion is implied.

Withdraw this result on any artifact/source/sidecar/generator pin drift, missing
regular inventory/golden entry, unanticipated vendor executable change, live
ready/capability/policy mismatch, missing/wrong source lineage, resume mutation
or duplicate IDs, or reliance on developer/global runtime tooling. It applies
only to the exact pins and tested profiles. Existing verified D remains a
separate unchanged deployment alternative.

**Conclusion: bounded PASS for the exact0f1b895 Windows/Linux policy/catalogue
runtime artifacts, their inventory-bound declaration and the four independently
executed packaged profiles; parent/GUI/live-model acceptance remains separate.**
