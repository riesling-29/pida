import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107');P=pathlib.Path('D:/ChantaResearchGroup/pida-execution-policy-20261108/.pida-test-runtime-catalogue-20261108')
sha=lambda b:hashlib.sha256(b).hexdigest();runtime=pathlib.Path('D:/pmcd-1108/runtime');m=json.loads((runtime/'manifest.json').read_text())
assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==m['source_commit']=='0f1b895d72d2f05a7c4fa21a2c9a5070aad71d8f'
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()
src=subprocess.check_output(['git','-C',str(S),'archive','--format=tar',m['source_commit']]);assert sha(src)==m['source']['source_archive_sha256'];assert sha((P/'windows/pida-core-0.8.18.tgz').read_bytes())==m['package']['sha256']
for key,path in [('managed_capabilities_generator_sha256','scripts/managed-host-capabilities.mjs'),('script_sha256','scripts/package-runtime.mjs'),('platform_lock_sha256','scripts/runtime-platform-lock.json')]:assert sha((S/path).read_bytes())==m['packaging'][key]
sidecar=sha((runtime/'managed-host-capabilities.json').read_bytes());assert sidecar=='862dea17a42aa001e9e20c810f36a97d3b577d985af908e98d19b676df701973'
archives=[];runtime_results={}
for plat,name,digest in [('windows','pida-runtime-0f1b895-win32-x64.tar.gz','550afde0caff9e0ae2a7e3acadb82c6ef64d8ceb967f85bec44d68a125be15e8'),('linux','pida-runtime-0f1b895-linux-x64.tar.gz','040733b5aa20e976705996e3af20f704357f98ddaed6b6dbc0e6ab1ae38fda4c')]:
 p=P/plat/name;assert sha(p.read_bytes())==digest;archives.append({'platform':plat,'archive':str(p),'sha256':digest,'bytes':p.stat().st_size})
 result=json.loads((E/(plat+'-runtime-probe.json')).read_text());assert result['status']=='PASS' and result['sidecar_sha256']==sidecar and len(result['scenarios'])==4
 for s in result['scenarios']:
  assert s['status']=='PASS' and s['resume_same_ids'] and s['token_rotated'] and s['policy_mismatch_no_mutation']
  if s['persona']!='local':assert all(r['inclusion_events']>0 for r in s['records'])
  if s['persona']=='catalogue':assert s['catalogue_mismatch_no_mutation'] and [r['source_id'] for r in s['records']]==['profile-a','profile-b']
 runtime_results[plat]={'scenarios':len(result['scenarios']),'native_jobs':sum(len(s['records']) for s in result['scenarios']),'source_receipts':sum(r['inclusion_events'] for s in result['scenarios'] if s['persona']!='local' for r in s['records'])}
windows=json.loads((E/'windows-delta.json').read_text(encoding='utf-8-sig'));linux=json.loads((E/'linux-delta.json').read_text(encoding='utf-8-sig'));built=[f for f in windows['changes'] if f['path'].startswith('pida/dist/')];assert len(built)==9;assert built==[f for f in linux['changes'] if f['path'].startswith('pida/dist/')]
metadata={'status':'PASS','source':m['source_commit'],'author_handoff':'71a7e17fd7d7096de57335d978dad724c299faaf','source_archive_sha256':sha(src),'package_sha256':m['package']['sha256'],'sidecar_sha256':sidecar,'packaging':m['packaging'],'archives':archives,'compiled_deltas':built,'runtime_results':runtime_results,'generator_review_sha256':'7769835cb8e545137a249aff0e2262413463da26b4f935e2d0b4b638b5bc697a','independent_probe_sha256':sha((E/'probe.mjs').read_bytes()),'author_original_probe_sha256':sha((E/'author-probe-original.mjs').read_bytes()),'probe_strengthening':'Require nonempty reference receipts, exact agentInstanceId and actual selected catalogue profile.','workspace_mismatch_snapshot_scope':'All workspace file bytes; directory metadata is not included by this probe.','python':'Explicit external Python3.11.9 Windows and3.14.4 Linux; not parent frozen service.'}
(E/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({k:v for k,v in metadata.items() if k not in ['compiled_deltas']}))
