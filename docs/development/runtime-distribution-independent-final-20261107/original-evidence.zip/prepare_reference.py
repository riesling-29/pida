import sys,json,hashlib,shutil,time,subprocess
from pathlib import Path
base,export,lockfile=map(Path,sys.argv[1:4]);base.mkdir(parents=True,exist_ok=False)
lock=json.loads(lockfile.read_text(encoding='utf-8'));source=base/'source'
for name,sha in lock['runtime_files'].items():
 data=(export/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
 target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
config={'schema_version':'vera-local-reference/0.1.0','principal':'principal:review','host_id':'packaged-probe','project_id':'schumpeter','memory_scope':['project:schumpeter','organization:review'],'persona':{'persona_id':'persona:review','name':'Review reference','description':'Synthetic reference value 73.','source_refs':['document:review-fixture']},'grant_expires_at':int(time.time())+3600}
configfile=base/'config.json';configfile.write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
entry=source/'scripts/local_persona_bridge.py';store=base/'store'
result=subprocess.run([sys.executable,'-I','-B',str(entry),'init','--config',str(configfile),'--store',str(store)],capture_output=True,text=True)
assert result.returncode==0,result.stderr
record={'executable':sys.executable,'python_version':sys.version,'entrypoint':str(entry),'config':str(configfile),'store':str(store),'source_digest':lock['source_digest'],'verified_source_files':len(lock['runtime_files']),'initialization':json.loads(result.stdout)}
(base/'provision.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
