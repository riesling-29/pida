import sys,json,hashlib,os,stat
from pathlib import Path
root=Path(sys.argv[1]); target=Path(sys.argv[2]); m=json.loads((root/'manifest.json').read_text())
diff=[]; expected=set()
for item in m['files']:
 p=root/item['path']; expected.add(item['path'])
 if not p.exists() and not p.is_symlink(): diff.append({'path':item['path'],'missing':True});continue
 if 'symlink' in item:
  if not p.is_symlink() or os.readlink(p)!=item['symlink']:diff.append({'path':item['path'],'symlinkMismatch':True})
  continue
 actual={'mode':stat.S_IMODE(p.stat().st_mode),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
 changed={key:{'expected':item[key],'actual':actual[key]} for key in actual if item[key]!=actual[key]}
 if changed:diff.append({'path':item['path'],**changed})
extras=[]
for directory,dirs,files in os.walk(root):
 for name in files:
  relative=(Path(directory)/name).relative_to(root).as_posix()
  if relative not in expected and relative!='manifest.json': extras.append(relative)
result={'root':str(root),'source':m['source_commit'],'platform':m['platform'],'expectedFiles':m['file_count'],'differences':diff,'extraFiles':extras}
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'differenceCount':len(diff),'extraFiles':extras,'first':diff[:10]}))
