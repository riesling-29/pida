import hashlib,json,pathlib,re,subprocess,tarfile
E=pathlib.Path('/mnt/d/ChantaResearchGroup/pida-runtime-distribution-review-evidence-20261107')
R=pathlib.Path('/var/tmp/pida-review-dist-r2-20261107/runtime')
T=pathlib.Path('/var/tmp/pida-review-dist-r2-20261107/official-extract');T.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
pins={'git':'c3b36d7357dea773eefe6c4f97ebff416e5afee22489dc1f729e31d6f47872e9','pcre2':'3e116766f1a7b149994d4745556023d993d26401223d1595520a991d4ba737fb','zlib':'450d9322ac4e9baea0f9a74548a20fde73b078235c1f5d1fb7084c2638e33cdd'}
for name,digest in pins.items():
 p=E/('official-'+name+'.deb');assert sha(p.read_bytes())==digest
 subprocess.run(['dpkg-deb','-x',str(p),str(T/name)],check=True)
matches=[('git','usr/bin/git','libexec/git-core/git'),('pcre2','usr/lib/x86_64-linux-gnu/libpcre2-8.so.0.14.0','lib/libpcre2-8.so.0'),('zlib','usr/lib/x86_64-linux-gnu/libz.so.1.3.1','lib/libz.so.1')]
for pkg,source,dest in matches:assert (T/pkg/source).read_bytes()==(R/'git'/dest).read_bytes(),dest
notices=0
for pkg,doc in [('git','git'),('pcre2','libpcre2-8-0'),('zlib','zlib1g')]:
 for p in (R/'git/share/doc'/doc).rglob('*'):
  if p.is_file():
   assert p.read_bytes()==(T/pkg/'usr/share/doc'/doc/p.relative_to(R/'git/share/doc'/doc)).read_bytes(),str(p)
   notices+=1
archive=pathlib.Path('/mnt/d/ChantaResearchGroup/pida/.pida-test-runtime-distribution-20261107/cache/node-v24.18.0-linux-x64.tar.xz')
with tarfile.open(archive) as t:
 for src,dst in [('bin/node','node'),('LICENSE','LICENSE'),('README.md','README.md')]:
  assert t.extractfile('node-v24.18.0-linux-x64/'+src).read()==(R/'node'/dst).read_bytes()
lm=json.loads((R/'manifest.json').read_text());wm=json.loads(pathlib.Path('/mnt/d/pdrv-20261107/runtime/manifest.json').read_text())
ld={f['path']:f['sha256'] for f in lm['files'] if f['path'].startswith('pida/dist/')};wd={f['path']:f['sha256'] for f in wm['files'] if f['path'].startswith('pida/dist/')};assert ld==wd
elf={}
for _,_,dest in matches:
 p=R/'git'/dest
 out=subprocess.check_output(['readelf','--version-info',str(p)],text=True)
 versions=set(re.findall(r'GLIBC_([0-9]+\.[0-9]+)',out));highest=max(versions,key=lambda v:tuple(map(int,v.split('.'))))
 elf[dest]={'highest_glibc_symbol':highest,'sha256':sha(p.read_bytes()),'dynamic':subprocess.check_output(['readelf','-d',str(p)],text=True),'interpreter':subprocess.check_output(['readelf','-l',str(p)],text=True)}
env=dict(__import__('os').environ);env['LD_LIBRARY_PATH']=str(R/'git/lib')
linkage=subprocess.check_output(['ldd',str(R/'git/libexec/git-core/git')],env=env,text=True)
assert str(R/'git/lib/libpcre2-8.so.0') in linkage and str(R/'git/lib/libz.so.1') in linkage
result={'status':'PASS','official_deb_sha256':pins,'selected_git_elf_and_libraries_byte_identical':True,'package_notice_files_byte_identical':notices,'node_binary_and_notices_byte_identical':True,'source_rebuilt_dist_files_cross_platform':len(ld),'elf':elf,'linkage':linkage,'glibc':subprocess.check_output(['getconf','GNU_LIBC_VERSION'],text=True).strip(),'os_release':pathlib.Path('/etc/os-release').read_text(),'scope':'Selected local Git binary; no general Linux or remote helper acceptance.'}
(E/'linux-r2-provenance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['elf','os_release']}))
