import sys,json,os,subprocess
from pathlib import Path
provision,node,probe,runtime,out=map(Path,sys.argv[1:6]);p=json.loads(provision.read_text());env=dict(os.environ)
env.update({'PIDA_PERSONA_BRIDGE_EXECUTABLE':p['executable'],'PIDA_PERSONA_BRIDGE_PREFIX_ARGS':json.dumps(['-I','-B',p['entrypoint']]),'PIDA_PERSONA_BRIDGE_CONFIG':p['config'],'PIDA_PERSONA_BRIDGE_STORE':p['store']})
r=subprocess.run([str(node),str(probe),str(runtime),str(out),'--reference'],env=env,capture_output=True,text=True,timeout=90)
out.with_suffix('.log').write_text(r.stdout+'\nSTDERR\n'+r.stderr,encoding='utf-8');print(r.stdout);print(r.stderr,file=sys.stderr);sys.exit(r.returncode)
