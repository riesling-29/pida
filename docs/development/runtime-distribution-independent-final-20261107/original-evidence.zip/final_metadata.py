import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
repo='D:/ChantaResearchGroup/pida'
R=pathlib.Path('D:/pdrv-20261107/runtime')
linux=json.loads(subprocess.check_output(['wsl','-d','Ubuntu','--','cat','/var/tmp/pida-review-dist-r2-20261107/runtime/manifest.json']))
for key,path in [('script_sha256','scripts/package-runtime.mjs'),('platform_lock_sha256','scripts/runtime-platform-lock.json')]:
 b=subprocess.check_output(['git','-C',repo,'show','46e22f5f3868e56ece5eaed9d0582ff7a160a800:'+path]);assert sha(b)==linux['packaging'][key]
metadata={'application_source':'bb9886ffc3a2a815e3c255b7dbfc83b4b4bac5e3','corrected_packaging_source':'46e22f5f3868e56ece5eaed9d0582ff7a160a800','packaging_hashes_verified':linux['packaging'],'windows_manifest_sha256':sha((R/'manifest.json').read_bytes()),'linux_manifest_sha256':'bdb1abd8c643b6b90854ff8a8e5f7ec40e837fc3c18f6a4c8d81cef8aeacc08a','observed_windows_version':subprocess.check_output(['cmd','/c','ver'],text=True).strip(),'runtime_probes':['windows-base.json','windows-reference.json','linux-r2-base.json','linux-r2-reference.json']}
for f in metadata['runtime_probes']:assert json.loads((E/f).read_text())['status']=='PASS'
(E/'review-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata))
