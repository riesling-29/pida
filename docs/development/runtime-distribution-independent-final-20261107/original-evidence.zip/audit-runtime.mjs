import assert from 'node:assert/strict';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root=resolve(process.argv[2]), out=resolve(process.argv[3]), m=JSON.parse(readFileSync(join(root,'manifest.json'),'utf8'));
const sha=b=>createHash('sha256').update(b).digest('hex'), lock=JSON.parse(readFileSync(join(root,'pida/npm-shrinkwrap.json'),'utf8'));
assert.equal(m.source_commit,'bb9886ffc3a2a815e3c255b7dbfc83b4b4bac5e3');
assert.equal(m.built_with.node,'v'+process.versions.node);assert.equal(m.built_with.abi.modules,process.versions.modules);
for(const d of m.dependencies){const pkg=JSON.parse(readFileSync(join(root,'pida',d.path,'package.json'),'utf8'));assert.equal(pkg.version,d.version);assert.equal(pkg.version,lock.packages[d.path].version);assert.equal(sha(readFileSync(join(root,'pida',d.path,'package.json'))),d.packageJsonSha256);assert.equal(d.dev,false);}
for(const file of m.license_files)assert.ok(readFileSync(join(root,file)).length>0,file);
for(const path of ['pida/node_modules/typescript','pida/node_modules/playwright','node/node_modules/npm','npm-cache','build-tools'])assert.equal(existsSync(join(root,path)),false,path);
const credentialNames=m.files.filter(f=>/(?:^|\/)(?:\.env|\.npmrc|credentials?\.json|auth\.json|id_rsa|id_ed25519)$/.test(f.path)).map(f=>f.path);
assert.deepEqual(credentialNames,[]);
const observation=join(root,'pida/examples/schumpeter-observation-tui.mjs');assert.ok(existsSync(observation));
const module=await import(pathToFileURL(join(root,'pida/dist/agent-tui.js')));assert.equal(typeof module.runAgentTerminal,'function');
const result={status:'PASS',platform:process.platform,source:m.source_commit,distribution:m.distribution_id,node:process.version,abi:process.versions.modules,dependencies:m.dependencies.length,licenseFiles:m.license_files.length,nativeAddonPaths:m.native_addon_paths,forbiddenCredentialFilenames:credentialNames,observationWrapperSha256:sha(readFileSync(observation)),agentTuiImport:true,excludedBuildTools:true,scope:'Static inventory and module load; no terminal/clipboard/native GUI or provider credentials used.'};
writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
