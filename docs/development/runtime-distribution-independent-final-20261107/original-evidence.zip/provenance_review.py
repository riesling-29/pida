import hashlib, json, pathlib, tarfile, zipfile
E=pathlib.Path(__file__).parent
P=pathlib.Path('D:/ChantaResearchGroup/pida/.pida-test-runtime-distribution-20261107')
W=pathlib.Path('D:/pdrv-20261107/runtime')
S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107')
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'checks':[]}
official={line.split()[1]:line.split()[0] for line in (E/'official-node-SHASUMS256.txt').read_text().splitlines() if line.strip()}
for name in ['node-v24.18.0-win-x64.zip','node-v24.18.0-linux-x64.tar.xz']:
 p=P/'cache'/name; digest=sha(p.read_bytes()); assert digest==official[name]
 result['checks'].append({'archive':name,'sha256':digest,'official_checksum_match':True})
with zipfile.ZipFile(P/'cache/node-v24.18.0-win-x64.zip') as z:
 for n in ['node.exe','LICENSE','README.md']:
  assert z.read('node-v24.18.0-win-x64/'+n)==(W/'node'/n).read_bytes()
result['windows_node_binary_and_notices']='byte-identical official ZIP'
mg=P/'MinGit-2.56.0.4-64-bit.zip'
assert sha(mg.read_bytes())=='e3bf78351fe777fba47ddee5950082f8a98bb0f02604fdc7ba3ee2cb68ffa877'
with zipfile.ZipFile(mg) as z:
 names=[n for n in z.namelist() if not n.endswith('/')]
 for n in names: assert z.read(n)==(W/'git'/n).read_bytes(),n
 actual={p.relative_to(W/'git').as_posix() for p in (W/'git').rglob('*') if p.is_file()}
 assert actual==set(names)
 result['mingit']={'archive_sha256':sha(mg.read_bytes()),'files_byte_identical':len(names),'extra_or_missing':[]}
dist=[p for p in (S/'dist').rglob('*') if p.is_file()]
for p in dist: assert p.read_bytes()==(W/'pida/dist'/p.relative_to(S/'dist')).read_bytes(),str(p)
assert {p.relative_to(S/'dist').as_posix() for p in dist}=={p.relative_to(W/'pida/dist').as_posix() for p in (W/'pida/dist').rglob('*') if p.is_file()}
result['exact_source_rebuilt_dist_files']=len(dist)
result['source_commit']='bb9886ffc3a2a815e3c255b7dbfc83b4b4bac5e3'
result['status']='PASS'
(E/'windows-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
