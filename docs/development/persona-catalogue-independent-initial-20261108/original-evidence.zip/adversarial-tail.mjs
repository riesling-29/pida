
import { existsSync } from 'node:fs';
import { hostname } from 'node:os';
test('independent: profile UUID must be a string with exact end boundary', {skip:!source}, async t=>{
  const f=await fixture(t),original=structuredClone(f.catalogue),outcomes=[];
  for(const value of [[original.sources[1].profile_id],original.sources[0].profile_id+'\n']) {
    f.catalogue.sources[0].profile_id=value;f.save();
    let accepted=false;try {await hostPersonaIdentity({hostId:f.hostId});accepted=true;}catch{}
    console.log(JSON.stringify({probe:'profile-id-type',kind:Array.isArray(value)?'array-of-other-profile-uuid':'uuid-final-newline',accepted}));
    outcomes.push(accepted);
  }
  assert.deepEqual(outcomes,[false,false]);
});
test('independent: same-source other-agent snapshots reject, native visibility cannot impersonate producer principal', {skip:!source}, async t=>{
  const f=await fixture(t), host={hostId:f.hostId};
  const bridge=await createHostPersona({...host,personaIdentity:await hostPersonaIdentity(host),taskScope:async taskId=>({jobId:taskId,attemptId:'attempt:independent',organizationTaskId:'orgtask:independent',organizationSessionId:'org:independent'})});t.after(()=>bridge.close());
  const contextA={principal,agentId:'agent:one',role:'review'},contextB={principal,agentId:'agent:two',role:'review'};
  const a=await bridge.personaSources[0].create(contextA),b=await bridge.personaSources[0].create(contextB);
  await assert.rejects(bridge.personaSources[0].create({...contextA,principal:{id:'provider:a'}}),/HOST_PERSONA_SOURCE_FORBIDDEN/);
  const request={...contextA,sessionId:'session:review',taskId:'job:review',runId:'run:review',signal:AbortSignal.timeout(4000)};
  const snapshot=await a.resolveContext(request);
  await assert.rejects(b.authorizeInput({...request,...contextB,snapshot,requestId:'request:review',attempt:1,inputDigest:'a'.repeat(64),fingerprintScope:'pi-logical-context/1',modelId:'faux',api:'faux'}),/HOST_PERSONA_SNAPSHOT_UNKNOWN/);
  const visible=await fixture(t);visible.catalogue.sources[0].principal_ids=['foreign-native'];visible.save();
  const app=await embedded(t,visible),overview=(await app.client.listAgents()).personaSources;
  assert.deepEqual(overview.sources.map(s=>s.id),['local','profile-b']);
  await assert.rejects(app.client.createAgent({name:'invisible',personaSourceId:'profile-a'}),{code:'AGENT_PERSONA_SOURCE_UNAVAILABLE'});
  const local=await app.client.createAgent({name:'explicit default'});assert.equal(local.personaSourceId,'local');
});

test('independent: producer startup failure on crash recovery preserves managed tree', {skip:!source}, async t=>{
  const f=await fixture(t), workspace=join(f.dir,'managed');
  const env={...process.env,PIDA_PERSONA_CATALOGUE:f.path,PIDA_SCHUMPETER_AUTH_URL:'http://127.0.0.1:1/v1/pida-authorization',PIDA_SCHUMPETER_AUTH_TOKEN:'independent-synthetic-policy-token-only'};
  async function launch(mode) {
    const child=spawn(process.execPath,[join(root,'examples/schumpeter-host.mjs'),'--workspace',workspace,'--host-id',f.hostId,'--workspace-mode',mode,'--persona-module',join(root,'examples/vera-local-reference-catalogue.mjs')],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    let stderr='',stdout='';child.stderr.on('data',x=>stderr+=x);child.stdout.on('data',x=>stdout+=x);
    const closed=new Promise(r=>child.once('close',code=>r({code,stderr,stdout})));
    const timer=setTimeout(()=>child.kill(),12000);t.after(()=>child.kill());
    return {child,closed,async stop(){child.stdin.end();const result=await closed;clearTimeout(timer);return result;},async done(){const result=await closed;clearTimeout(timer);return result;},async ready(){await until(()=>stdout.includes('pida-host-ready'));}};
  }
  const h=await launch('fresh');await h.ready();assert.equal((await h.stop()).code,0);
  const dead=spawnSync(process.execPath,['-e','process.exit(0)']);assert.equal(dead.status,0);
  assert.throws(()=>process.kill(dead.pid,0),{code:'ESRCH'});
  const runtimeLock=join(workspace,'.pida/runtime.lock');writeFileSync(runtimeLock,JSON.stringify({pid:dead.pid,host:hostname(),nonce:'synthetic-crash-lock'}));
  const b=f.catalogue.sources[1];writeFileSync(join(b.bridge.store,'reference.sqlite3'),'synthetic-corrupted-db');
  function tree(path,rel='',value={}){for(const e of readdirSync(path,{withFileTypes:true})){const key=rel+e.name;if(e.isDirectory())tree(join(path,e.name),key+'/',value);else value[key]=sha(readFileSync(join(path,e.name)));}return value;}
  const before=tree(workspace),failure=await(await launch('resume')).done(),after=tree(workspace);
  assert.equal(failure.code,1);assert.ok(!failure.stdout.includes('pida-host-ready'));
  console.log(JSON.stringify({probe:'failed-producer-resume',exit:failure.code,error:failure.stderr.trim(),runtime_lock_before:Object.hasOwn(before,'.pida/runtime.lock'),runtime_lock_after:existsSync(runtimeLock),changed_keys:[...new Set([...Object.keys(before),...Object.keys(after)])].filter(k=>before[k]!==after[k])}));
  assert.deepEqual(after,before);
});
