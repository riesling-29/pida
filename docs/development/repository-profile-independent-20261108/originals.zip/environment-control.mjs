import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const env={SystemRoot:process.env.SystemRoot??process.env.SYSTEMROOT};
const result=spawnSync(process.execPath,['--input-type=module','-e','console.log(JSON.stringify(Object.keys(process.env).map(k=>k.toLowerCase()).sort()))'],{env,encoding:'utf8',windowsHide:true});
if(result.status!==0)throw Error('DIRECT_SPAWN_CONTROL_FAILED');
const keys=JSON.parse(result.stdout),report={scope:'Independent direct child control: explicit env contains only SystemRoot; output records names, never values',platform:process.platform,node_version:process.version,explicit_names:Object.keys(env).map(k=>k.toLowerCase()),actual_child_names:keys,additional_names:keys.filter(k=>k!=='systemroot')};
writeFileSync(new URL('./environment-control.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
