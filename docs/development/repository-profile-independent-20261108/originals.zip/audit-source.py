import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path('D:/ChantaResearchGroup/pida-repository-review-20261108')
out=pathlib.Path(__file__).parent
e=root/'docs/development/repository-profile-evidence-20261108'
m=json.loads((e/'manifest.json').read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(name,passed): checks.append({'name':name,'pass':bool(passed)})
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
pin='b5252fba5a66c2c40dca49017a4a4b929a47170a'
check('exact review head',git('rev-parse','HEAD').decode().strip()==pin)
check('tracked source unchanged',not git('diff',pin,'--'))
sources=[]
for name,expected in m['source_files'].items():
 actual=sha((root/name).read_bytes());sources.append({'path':name,'sha256':actual});check(name+' producer source hash',actual==expected)
for name,expected in m['unchanged_critical_files'].items():
 actual=(root/name).read_bytes();base=git('show',m['base_commit']+':'+name)
 check(name+' unchanged critical bytes',actual==base and sha(actual)==expected['working_sha256'])
check('raw log archive hash',sha((e/'raw-logs.zip').read_bytes())==m['raw_archive_sha256'])
with zipfile.ZipFile(e/'raw-logs.zip') as z:
 for record in m['logs']:
  candidates=[n for n in z.namelist() if pathlib.PurePosixPath(n).name==record['original_name']]
  check(record['original_name']+' raw log hash',len(candidates)==1 and sha(z.read(candidates[0]))==record['original_sha256'])
  check(record['readable_copy']+' readable hash',sha((e/record['readable_copy']).read_bytes())==record['readable_sha256'])
plain=subprocess.run(['git','diff','HEAD^','HEAD','--check'],cwd=root,capture_output=True)
crlf=subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','HEAD^','HEAD','--check'],cwd=root,capture_output=True)
check('CRLF-aware diff integrity',crlf.returncode==0)
report={'source_commit':pin,'base_commit':m['base_commit'],'source_files':sources,'checks':checks,'failures':[c['name'] for c in checks if not c['pass']], 'diff_integrity':{'plain_exit':plain.returncode,'cr_at_eol_exit':crlf.returncode},'limits':['Linux and historical broader proxy test outcomes remain owner evidence, not independently rerun here.','No raw log archive extraction or package mutation.']}
(out/'source-audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'failures':report['failures'],'plain_diff_exit':plain.returncode,'cr_at_eol_diff_exit':crlf.returncode}))
