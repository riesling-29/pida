import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createManagedCapabilities} from '../pida-review-distribution-20261107/scripts/managed-host-capabilities.mjs';
const bytes=JSON.stringify(createManagedCapabilities('0f1b895d72d2f05a7c4fa21a2c9a5070aad71d8f','catalogue/1'),null,2)+'\n';
const prior=readFileSync('D:/pmcd-1108/runtime/managed-host-capabilities.json','utf8');assert.equal(bytes,prior);
writeFileSync('D:/ChantaResearchGroup/pida-repository-sidecar2-review-evidence-20261108/legacy-equivalence.json',JSON.stringify({status:'PASS',same_source_catalogue1_bytes_identical:true,sha256:createHash('sha256').update(bytes).digest('hex')},null,2)+'\n');
