import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,lstatSync,readlinkSync,symlinkSync,linkSync,renameSync,unlinkSync} from 'node:fs';
import {join,relative,resolve,sep} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const [sourceArg,baseArg,outArg]=process.argv.slice(2),sourceRoot=resolve(sourceArg),base=mkdtempSync(join(resolve(baseArg),'run-')),out=resolve(outArg);
const {createManagedCapabilities}=await import(pathToFileURL(join(sourceRoot,'scripts/managed-host-capabilities.mjs')));
const source='e9a1d31140bcff34e3c9ef0f82f4b3dbca0ddd68',sha=b=>createHash('sha256').update(b).digest('hex'),results=[];
function fixture(label,change=()=>{},mode='repository/1',expected='MANAGED_CAPABILITIES_INVALID'){
 const root=join(base,label);mkdirSync(root);const cap=structuredClone(createManagedCapabilities(source,mode)),extra={};
 const put=(name,data)=>{const p=join(root,name);mkdirSync(join(p,'..'),{recursive:true});writeFileSync(p,data);};
 const modulePaths=[cap.entrypoint,'pida/dist/execution-policy.js','pida/examples/vera-local-reference-catalogue.mjs','pida/examples/vera-local-reference-persona.mjs','pida/fixtures/vera-dispatch/local-reference-source-lock.json','pida/examples/repository-profile.mjs','pida/dist/repository-profile.js'];
 for(const p of modulePaths)put(p,'inert synthetic module, never executed');
 for(const p of ['execution-policy/profiles-v1.json','repository-profile/managed-descriptor-v1.json','repository-profile/capability-v1.json'])put('pida/fixtures/'+p,readFileSync(join(sourceRoot,'fixtures',p)));
 put('managed-host-capabilities.json',JSON.stringify(cap));change({root,cap,put,extra});
 const files=[];function walk(dir){for(const name of readdirSync(dir)){const p=join(dir,name),s=lstatSync(p),path=relative(root,p).split(sep).join('/');if(s.isSymbolicLink())files.push({path,symlink:readlinkSync(p)});else if(s.isDirectory())walk(p);else files.push({path,bytes:s.size,mode:s.mode&0o777,sha256:sha(readFileSync(p))});}}walk(root);files.sort((a,b)=>a.path<b.path?-1:1);
 const manifest={schema_version:'pida.runtime-distribution/1',distribution_id:'independent-sidecar2-fixture',platform:process.platform+'-'+process.arch,source_commit:source,source:{source_commit:source},file_count:files.length,tree_sha256:sha(JSON.stringify(files)),files,...extra.manifest};
 const bytes=JSON.stringify(manifest);put('manifest.json',bytes);extra.after?.(root);const pin=extra.pin??sha(bytes);
 const r=spawnSync(process.execPath,[join(sourceRoot,'scripts/verify-runtime-distribution.mjs'),root,pin],{encoding:'utf8',windowsHide:true});
 const record={label,expected,status:r.status,stdout:r.stdout,stderr:r.stderr,root,manifest_sha256:pin,manifest};results.push(record);
 if(expected==='PASS')assert.equal(r.status,0,r.stderr);else{assert.notEqual(r.status,0,label);assert.match(r.stderr,new RegExp(expected),label);}
}
try{
 fixture('valid-repository',()=>{},'repository/1','PASS');fixture('valid-catalogue1',()=>{},'catalogue/1','PASS');fixture('valid-policy1',()=>{},'policy/1','PASS');
 fixture('legacy-absence',({root})=>unlinkSync(join(root,'managed-host-capabilities.json')),'catalogue/1','PASS');
 const bad=[['missing-descriptor',v=>delete v.repository_profile],['null-descriptor',v=>v.repository_profile=null],['partial-descriptor',v=>delete v.repository_profile.id],['unknown-descriptor-key',v=>v.repository_profile.extra=1],['wrong-module',v=>v.repository_profile.module='../escape.mjs'],['wrong-environment',v=>v.repository_profile.environment_key='MODEL_PATH'],['descriptor-wrong-ready',v=>v.repository_profile.ready_protocol='pida.local-host/2'],['descriptor-wrong-workspace',v=>v.repository_profile.workspace_schema='pida.local-host.workspace/2'],['descriptor-wrong-admission',v=>v.repository_profile.admission_capabilities='pida.organization.admission.capabilities/2'],['top-mode3',v=>v.ready_protocol='pida.local-host/3'],['null-catalogue',v=>v.persona_catalogue=null],['downgraded-schema-with-repository',v=>v.schema_version='pida.managed-host.capabilities/1'],['unknown-schema',v=>v.schema_version='pida.managed-host.capabilities/99'],['unknown-top-key',v=>v.extra=true],['wrong-source',v=>v.source_commit='a'.repeat(40)],['altered-policy-digest',v=>v.execution_policy.profiles[0].digest='b'.repeat(64)]];
 for(const [label,change]of bad)fixture(label,({cap,put})=>{change(cap);put('managed-host-capabilities.json',JSON.stringify(cap));});
 fixture('source-provenance-mismatch',({extra})=>extra.manifest={source:{source_commit:'a'.repeat(40)}});
 for(const [label,path]of [['missing-repository-module','pida/examples/repository-profile.mjs'],['missing-repository-dist','pida/dist/repository-profile.js'],['missing-descriptor-golden','pida/fixtures/repository-profile/managed-descriptor-v1.json'],['missing-shape-golden','pida/fixtures/repository-profile/capability-v1.json']])fixture(label,({root})=>unlinkSync(join(root,path)));
 fixture('wrong-descriptor-golden',({root,put})=>{const p='pida/fixtures/repository-profile/managed-descriptor-v1.json',g=JSON.parse(readFileSync(join(root,p)));g.extra=true;put(p,JSON.stringify(g));});
 fixture('wrong-shape-golden',({root,put})=>{const p='pida/fixtures/repository-profile/capability-v1.json',g=JSON.parse(readFileSync(join(root,p)));g.trusted_host_shell=true;put(p,JSON.stringify(g));},'repository/1','REPOSITORY_CAPABILITY_INVALID');
 fixture('shape-sample-is-not-real-approval',({root,put})=>{const p='pida/fixtures/repository-profile/capability-v1.json',g=JSON.parse(readFileSync(join(root,p)));g.digest='c'.repeat(64);g.program.approval_digest='d'.repeat(64);put(p,JSON.stringify(g));},'repository/1','PASS');
 fixture('oversize-descriptor-golden',({root,put})=>{const p='pida/fixtures/repository-profile/managed-descriptor-v1.json';put(p,readFileSync(join(root,p),'utf8')+' '.repeat(17000));});
 fixture('module-parent-link',({root})=>{renameSync(join(root,'pida/examples'),join(root,'module-targets'));symlinkSync(join(root,'module-targets'),join(root,'pida/examples'),process.platform==='win32'?'junction':'dir');});
 fixture('golden-parent-link',({root})=>{renameSync(join(root,'pida/fixtures/repository-profile'),join(root,'golden-targets'));symlinkSync(join(root,'golden-targets'),join(root,'pida/fixtures/repository-profile'),process.platform==='win32'?'junction':'dir');});
 fixture('module-hardlink',({root})=>linkSync(join(root,'pida/examples/repository-profile.mjs'),join(root,'module-copy')));
 fixture('sidecar-hardlink',({root})=>linkSync(join(root,'managed-host-capabilities.json'),join(root,'sidecar-copy')));
 fixture('wrong-external-pin',({extra})=>extra.pin='0'.repeat(64),'repository/1','MANIFEST_HASH_MISMATCH');
 fixture('unverified-malformed-sidecar',({extra})=>extra.after=root=>writeFileSync(join(root,'managed-host-capabilities.json'),'{broken'),'repository/1','RUNTIME_TREE_MISMATCH');
 fixture('missing-sidecar-under-old-pin',({extra})=>extra.after=root=>unlinkSync(join(root,'managed-host-capabilities.json')),'repository/1','RUNTIME_TREE_MISMATCH');
 writeFileSync(out,JSON.stringify({status:'PASS',source,platform:process.platform,base,cases:results.length,results},null,2)+'\n');console.log(JSON.stringify({status:'PASS',platform:process.platform,cases:results.length,accepted:results.filter(r=>r.status===0).length,rejected:results.filter(r=>r.status!==0).length}));
}catch(e){writeFileSync(out,JSON.stringify({status:'FAIL',source,platform:process.platform,base,error:e.message,results},null,2)+'\n');throw e;}
