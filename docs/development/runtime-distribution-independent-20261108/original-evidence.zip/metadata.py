import hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent
S=pathlib.Path('D:/ChantaResearchGroup/pida-review-distribution-20261107')
P=pathlib.Path('D:/ChantaResearchGroup/pida/.pida-test-runtime-distribution-20261108')
R=pathlib.Path('D:/pdrv-20261108/runtime')
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'manifest.json').read_text())
assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==m['source_commit']
assert subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()==''
source_bytes=subprocess.check_output(['git','-C',str(S),'archive','--format=tar',m['source_commit']])
assert sha(source_bytes)==m['source']['source_archive_sha256']
assert sha((P/'windows/pida-core-0.8.18.tgz').read_bytes())==m['package']['sha256']
for key,path in [('script_sha256','scripts/package-runtime.mjs'),('platform_lock_sha256','scripts/runtime-platform-lock.json')]:assert sha((S/path).read_bytes())==m['packaging'][key]
assert (E/'organization-yield.test.mjs').read_bytes()==(S/'test/organization-yield.test.mjs').read_bytes()
archives=[]
for plat,name,digest in [('windows','pida-runtime-2b787fd-win32-x64.tar.gz','db9e1041ec932165adcbe383a38a5178cf3b58f0654db245e6783c8db2302986'),('linux','pida-runtime-2b787fd-linux-x64.tar.gz','dcb721282aaca7c1c83c7ce7f3fa25e700b437df79a8f2b2cab37d75f134bd33')]:
 p=P/plat/name;assert sha(p.read_bytes())==digest
 archives.append({'platform':plat,'archive':str(p),'sha256':digest,'bytes':p.stat().st_size})
result={'source':m['source_commit'],'source_worktree_clean':True,'source_archive_sha256':sha(source_bytes),'npm_archive_sha256':m['package']['sha256'],'packaging':m['packaging'],'archives':archives,'packaged_test_source_sha256':sha((E/'organization-yield.test.mjs').read_bytes()),'packaged_test_transport_sha256':sha((E/'probe-packaged-yield.mjs').read_bytes()),'independent_base_and_sdk_probes':True,'reference_persona_on_new_build':'author evidence only; not independently rerun in this narrow delta','previous_independent_vendor_provenance_report_sha256':'fdf273daffac7195873913f50684ffcbe031b44449f02c130a09fb544d457823'}
(E/'metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
