import test from 'node:test';
import assert from 'node:assert/strict';
import {fauxProvider,fauxAssistantMessage as answer} from '@earendil-works/pi-ai/providers/faux';
import {PidaRuntime} from './dist/runtime.js';
import {providerRejectionCode} from './dist/provider-diagnostic.js';
import {validateObservationBundle} from './dist/integration-contract.js';
const quota='The ChatGPT user has reached their Subscription Sharing usage limit. Ask the user to try again after their usage limit resets or use an API key instead.';
const principal={id:'review-owner',permissions:[]};
async function fixture(steps,options={},identity={provider:'openai',api:'openai-responses'}){
 const f=fauxProvider({...identity,tokensPerSecond:100000});f.setResponses(steps);
 const runtime=new PidaRuntime({provider:()=>({provider:f.provider,modelId:f.getModel().id}),maxProviderRetries:0,maxOutputRetries:0,...options});
 const{sessionId}=await runtime.createSession(principal);return{f,runtime,sessionId};
}
function check(runtime,sessionId,result,emitted,expected){
 const bundle=runtime.exportRun(sessionId,result.runId,principal),traces=runtime.getTrace(sessionId,principal),diagnostics=traces.filter(e=>e.type==='provider_rejected'),observed=bundle.events.filter(e=>e.activity==='provider_rejected');
 assert.equal(validateObservationBundle(bundle).valid,true);assert.equal(diagnostics.length,expected?1:0);assert.equal(observed.length,diagnostics.length);assert.equal(emitted.filter(e=>e.type==='trace'&&e.trace.type==='provider_rejected').length,diagnostics.length);
 const finished=bundle.events.filter(e=>e.activity==='run_finished').at(-1);assert.equal(finished.payload.status,result.status);assert.equal(finished.payload.code,result.code??null);
 if(expected){const d=diagnostics[0],response=bundle.events.filter(e=>e.activity==='model_response').at(-1);assert.equal(d.code,expected);assert.equal(d.runId,result.runId);assert.equal(d.sessionId,result.sessionId);assert.deepEqual(Object.keys(d).sort(),['code','runId','sequence','sessionId','timestamp','type']);assert.equal(observed[0].payload.request_id,response.payload.request_id);assert.equal(observed[0].payload.attempt,response.payload.attempt);assert.equal(response.payload.code,expected);assert.equal(response.payload.usage_status,'unknown');assert.equal(response.payload.tokens,null);assert.equal(response.payload.cost_usd,null);assert.deepEqual(emitted.slice(-3).map(e=>e.type==='trace'?e.trace.type:e.type),['provider_rejected','run_finished','result']);}
 return{bundle,traces};
}

test('review: token guard, cost guard and unguarded error retain primary semantics and same safe final diagnostic',async()=>{
 for(const options of [{maxTotalTokens:100},{maxCostUsd:1,pricingVerified:true},{}]){
  const f=await fixture([()=>{throw Error(quota);}],options),emitted=[];
  try{const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e));const guarded=Object.keys(options).length>0;assert.equal(result.status,guarded?'limited':'failed');assert.equal(result.code,guarded?'USAGE_UNAVAILABLE':'PROVIDER_FAILED');assert.equal(result.text,'');assert.equal(f.f.state.callCount,1);const values=check(f.runtime,f.sessionId,result,emitted,'PROVIDER_SUBSCRIPTION_SHARING_LIMIT');assert.ok(!JSON.stringify([result,values]).includes(quota));}
  finally{await f.runtime.close();}
 }
});

test('review: wrong family, secret suffix and oversized text cannot become specific quota diagnostic or leak',async()=>{
 const variants=[{identity:{provider:'private-backend',api:'openai-responses'},message:quota},{identity:{provider:'openai',api:'private-api'},message:quota},
  {message:quota+' Bearer synthetic-private-secret'},{message:'synthetic-private-secret '+quota},{message:' '.repeat(2050)+quota}];
 for(const v of variants){const f=await fixture([()=>{throw Error(v.message);}],{maxTotalTokens:100},v.identity),emitted=[];try{const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e));const values=check(f.runtime,f.sessionId,result,emitted,'PROVIDER_REJECTED');assert.ok(!JSON.stringify([result,values]).includes('synthetic-private-secret'));assert.equal(result.code,'USAGE_UNAVAILABLE');assert.equal(f.f.state.callCount,1);}finally{await f.runtime.close();}}
 assert.equal(providerRejectionCode({provider:'openai',api:'openai-responses',stopReason:'error',errorMessage:' \n'+quota+'\t'}),'PROVIDER_SUBSCRIPTION_SHARING_LIMIT');
});

test('review: cancellation and deadline cannot promote an error envelope to terminal provider rejection',async()=>{
 for(const mode of ['cancel','deadline']){const controller=new AbortController();const f=await fixture([async(_context,options)=>new Promise((resolve,reject)=>{options.signal.addEventListener('abort',()=>reject(Error(quota)),{once:true});})],mode==='deadline'?{maxRunMs:100}:{maxRunMs:1000}),emitted=[];
 let timer;try{if(mode==='cancel')timer=setTimeout(()=>controller.abort(),30);const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e),controller.signal);assert.equal(result.code,mode==='cancel'?'CANCELLED':'RUN_TIMEOUT');check(f.runtime,f.sessionId,result,emitted,undefined);assert.equal(f.f.state.callCount,1);}finally{clearTimeout(timer);await f.runtime.close();}}
});

test('review: aborted final assistant is not provider rejection',async()=>{
 const f=await fixture([()=>answer('',{stopReason:'aborted',errorMessage:quota})]),emitted=[];try{const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e));assert.equal(result.status,'failed');assert.equal(result.code,'PROVIDER_FAILED');check(f.runtime,f.sessionId,result,emitted,undefined);assert.equal(f.f.state.callCount,1);}finally{await f.runtime.close();}
});

test('review: exhausted retries emit one terminal trace bound to final attempt only',async()=>{
 const f=await fixture([()=>{throw Error('429 rate limit synthetic-private-first');},()=>{throw Error('429 rate limit synthetic-private-final');}],{maxProviderRetries:1,retryBaseDelayMs:0,retryMaxDelayMs:0}),emitted=[];
 try{const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e));assert.equal(result.status,'failed');assert.equal(result.code,'PROVIDER_RETRY_EXHAUSTED');assert.equal(f.f.state.callCount,2);const values=check(f.runtime,f.sessionId,result,emitted,'PROVIDER_REJECTED');const responses=values.bundle.events.filter(e=>e.activity==='model_response');assert.equal(responses.length,2);assert.notEqual(responses[0].payload.request_id,responses[1].payload.request_id);assert.ok(!JSON.stringify([result,values]).includes('synthetic-private'));}
 finally{await f.runtime.close();}
});

test('review: OCEL preserves rejection classification and primary status without inventing zero usage',async()=>{
 const f=await fixture([()=>{throw Error(quota);}],{maxTotalTokens:100}),emitted=[];
 try{const result=await f.runtime.run(f.sessionId,principal,'Synthetic',e=>emitted.push(e));check(f.runtime,f.sessionId,result,emitted,'PROVIDER_SUBSCRIPTION_SHARING_LIMIT');const ocel=f.runtime.exportRunOcel(f.sessionId,result.runId,principal),attr=e=>Object.fromEntries(e.attributes.map(a=>[a.name,a.value]));
 const response=attr(ocel.document.events.find(e=>e.type==='model_response')),terminal=attr(ocel.document.events.find(e=>e.type==='provider_rejected')),finished=attr(ocel.document.events.find(e=>e.type==='run_finished'));
 assert.equal(response['payload.code'],'PROVIDER_SUBSCRIPTION_SHARING_LIMIT');assert.equal(response['payload.usage_status'],'unknown');assert.equal(response['payload.tokens'],undefined);assert.equal(response['payload.cost_usd'],undefined);assert.equal(terminal['payload.request_id'],response['payload.request_id']);assert.equal(terminal['payload.attempt'],response['payload.attempt']);assert.equal(finished['payload.status'],'limited');assert.equal(finished['payload.code'],'USAGE_UNAVAILABLE');assert.ok(!JSON.stringify(ocel).includes(quota));assert.equal(f.f.state.callCount,1);
 }finally{await f.runtime.close();}
});
