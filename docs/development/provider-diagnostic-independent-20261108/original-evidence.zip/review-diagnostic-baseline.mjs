import assert from 'node:assert/strict';
import {PidaRuntime} from './dist/runtime.js';
import {fauxProvider,fauxAssistantMessage as answer} from '@earendil-works/pi-ai/providers/faux';
const owner={id:'review-owner',permissions:[]},f=fauxProvider({tokensPerSecond:100000});let calls=0;
f.setResponses([()=>{calls++;throw Error('ChatGPT Subscription Sharing usage limit reached. synthetic-private-token');}]);
const runtime=new PidaRuntime({provider:()=>({provider:f.provider,modelId:f.getModel().id}),maxTotalTokens:100,maxProviderRetries:0});
try{const{sessionId}=await runtime.createSession(owner),result=await runtime.run(sessionId,owner,'Synthetic offline negative diagnostic case.');const bundle=runtime.exportRun(sessionId,result.runId,owner),trace=runtime.getTrace(sessionId,owner);const response=bundle.events.find(e=>e.activity==='model_response');
assert.equal(result.code,'USAGE_UNAVAILABLE');assert.equal(result.status,'limited');assert.equal(response.payload.usage_status,'unknown');assert.equal(response.payload.tokens,null);assert.equal(calls,1);assert.ok(!JSON.stringify([result,bundle,trace]).includes('synthetic-private-token'));
console.log(JSON.stringify({case:'offline-zero-placeholder-error',status:result.status,code:result.code,usage_status:response.payload.usage_status,tokens:response.payload.tokens,modelCalls:calls,providerDiagnosticTraceCount:trace.filter(e=>e.type==='provider_rejected').length}));
}finally{await runtime.close();}
