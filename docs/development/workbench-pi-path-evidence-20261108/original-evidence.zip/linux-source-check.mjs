﻿import {cpSync,mkdirSync,symlinkSync,readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const root='/var/tmp/pida-workbench-path-source-20261108',repo='/mnt/d/ChantaResearchGroup/pida',old='/var/tmp/pida-2b787fd-20261108/extracted/runtime';
mkdirSync(root);mkdirSync(root+'/pida');mkdirSync(root+'/node');cpSync(repo+'/dist',root+'/pida/dist',{recursive:true});cpSync(repo+'/package.json',root+'/pida/package.json');symlinkSync(old+'/pida/node_modules',root+'/pida/node_modules','dir');symlinkSync(old+'/git',root+'/git','dir');symlinkSync(old+'/node/node',root+'/node/node');
for(const test of ['workbench-pi-path.test.mjs','workbench.test.mjs']){
 const output=repo+'/.pida-test-workbench-path-20261108/linux-'+test+'.log';const r=spawnSync(process.execPath,[repo+'/.pida-test-runtime-distribution-20261108/probe-packaged-yield.mjs',root,repo+'/test/'+test,output],{encoding:'utf8'});writeFileSync(output+'.runner.log',(r.stdout??'')+(r.stderr??''));if(r.status!==0)throw Error('TEST_FAILED:'+test+':'+r.status);console.log(test+':PASS');
}
