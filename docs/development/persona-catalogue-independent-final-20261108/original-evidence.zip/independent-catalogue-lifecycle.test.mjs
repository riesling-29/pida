import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, writeFileSync, renameSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir, hostname } from 'node:os';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { fauxProvider, fauxAssistantMessage as answer } from '@earendil-works/pi-ai/providers/faux';
import { initWorkspace, readConfig, createWorkspace, workspaceEnvironment } from '../dist/workspace.js';
import { resolveExecutionPolicy } from '../dist/execution-policy.js';
import { PidaClient } from '../dist/client.js';
import { referenceHostSettings } from '../examples/vera-local-reference-persona.mjs';
import { hostPersonaIdentity, createHostPersona } from '../examples/vera-local-reference-catalogue.mjs';
const root = fileURLToPath(new URL('../', import.meta.url)), source = process.env.PIDA_TEST_LOCAL_REFERENCE;
const sha = x => createHash('sha256').update(x).digest('hex');
const principal = { id: 'local-user', permissions: ['pida:collaborate'] };
async function until(fn) { for(let n=0;n<500;n++){const v=await fn();if(v)return v;await delay(20);}assert.fail('TEST_TIMEOUT'); }
function python(executable, args) { const r=spawnSync(executable,args,{encoding:'utf8'});assert.equal(r.status,0,r.stderr+r.stdout);return r.stdout; }
async function fixture(t, expiredB=false) {
  const lock=JSON.parse(readFileSync(join(root,'fixtures/vera-dispatch/local-reference-source-lock.json')));
  for(const [p,h] of Object.entries(lock.runtime_files)) assert.equal(sha(readFileSync(join(source,p))),h);
  const dir=mkdtempSync(join(tmpdir(),'pdcat-')), hostId='catalogue-host', path=join(dir,'catalogue.json');
  const executable=python(process.env.PYTHON??'python',['-c','import sys;print(sys.executable)']).trim();
  const entry=join(resolve(source),'scripts/local_persona_bridge.py'), sources=[];
  for(const id of ['a','b']) {
    const config=join(dir,id+'.json'), store=join(dir,id+'-store');
    const value={schema_version:'vera-local-reference/0.1.0',principal:'provider:'+id,host_id:hostId,project_id:'schumpeter',memory_scope:['project:schumpeter'],
      persona:{persona_id:'persona:'+id,name:'Reference '+id,description:'SYNTHETIC_'+id.toUpperCase()+'_ONLY',source_refs:['document:catalogue-test']},grant_expires_at:expiredB&&id==='b'?100:Math.floor(Date.now()/1000)+3600};
    writeFileSync(config,JSON.stringify(value));
    if(expiredB&&id==='b') python(executable,['-I','-B','-c',`import sys;sys.path.insert(0,sys.argv[1]);from persona_substrate.local_bridge import initialize_store;initialize_store(sys.argv[2],sys.argv[3],clock=lambda:1)`,resolve(source),config,store]);
    else python(executable,['-I','-B',entry,'init','--config',config,'--store',store]);
    const bridge={executable,prefix_args:['-I','-B',entry],config,store}, selected=await referenceHostSettings({hostId},bridge);
    sources.push({id:'profile-'+id,label:'Reference '+id,profile_id:randomUUID(),persona_id:value.persona.persona_id,principal_ids:['local-user'],bridge,config_sha256:sha(readFileSync(config)),store_instance_id:selected.storeIdentity.store_instance_id,bridge_identity:selected.identity});
  }
  const catalogue={schema_version:'pida.persona-catalogue/1',host_id:hostId,sources};
  const save=()=>writeFileSync(path,JSON.stringify(catalogue));save();
  const previous=process.env.PIDA_PERSONA_CATALOGUE;process.env.PIDA_PERSONA_CATALOGUE=path;
  t.after(()=>{if(previous===undefined)delete process.env.PIDA_PERSONA_CATALOGUE;else process.env.PIDA_PERSONA_CATALOGUE=previous;});
  return {dir,path,hostId,executable,entry,catalogue,save};
}
async function embedded(t,f) {
  const workspace=join(f.dir,'workspace');initWorkspace(workspace);
  writeFileSync(join(workspace,'pida.config.json'),JSON.stringify({...readConfig(workspace),preset:'personal',tools:{directory:'tools',enabled:[]},workbench:{enabled:false},codingPacks:[],permissions:principal.permissions}));
  let app,bridge;
  const close=async()=>{if(app){await app.close();app.server.closeAllConnections();await new Promise(r=>app.server.close(r));app=undefined;}await bridge?.close();bridge=undefined;};
  const open=async()=>{
    bridge=await createHostPersona({hostId:f.hostId,personaIdentity:await hostPersonaIdentity({hostId:f.hostId}),async taskScope(taskId,agentId){
      const job=app.agents.getJob(taskId,principal);assert.equal(job.agentId,agentId);
      for(const org of app.agents.listOrganizations(principal)){const view=await app.agents.getOrganization(org.id,principal);
        if(view.tasks.some(t=>t.id===job.organizationTaskId&&t.agentId===agentId)&&view.attempts.some(a=>a.id===job.attemptId&&a.jobId===job.id))return {jobId:job.id,attemptId:job.attemptId,organizationTaskId:job.organizationTaskId,organizationSessionId:org.id};}
      throw Error('HOST_PERSONA_ORGANIZATION_REQUIRED');
    }});
    app=await createWorkspace(workspace,{personaSources:bridge.personaSources,executionPolicy:resolveExecutionPolicy('smoke/1')});
    app.server.listen(0,'127.0.0.1');await once(app.server,'listening');
    return new PidaClient({baseUrl:'http://127.0.0.1:'+app.server.address().port,token:()=>workspaceEnvironment(workspace).PIDA_API_TOKEN});
  };
  t.after(close);let client=await open();
  return {get app(){return app;},get client(){return client;},bridge,async restart(){await close();client=await open();},workspace};
}
async function run(f,agent,id,calls) {
  const runtime=await f.app.agents.getRuntime(agent.id,principal), faux=fauxProvider({tokensPerSecond:100000});
  faux.setResponses([context=>{calls.push({agent:agent.id,text:JSON.stringify(context)});return answer('Synthetic completion');}]);
  runtime.configureProvider(()=>({provider:faux.provider,modelId:faux.getModel().id}),{mode:'offline-catalogue-fixture',model:'faux'});
  const org=await f.client.createOrganization({requestId:id,goal:'Check the configured reference.',agentId:agent.id,participants:[agent.id],criterionIds:[]});
  const job=await until(async()=>{const list=await f.client.listAgentJobs(agent.id);return list.jobs.find(j=>j.organizationTaskId===org.rootTaskId&&!['queued','running'].includes(j.status));});
  return {job,org,bundle:await f.client.exportAgentJob(agent.id,job.id)};
}
function included(value,agent,persona,count=1){
  assert.equal(value.job.status,'completed',JSON.stringify(value.job));
  const events=value.bundle.events.filter(e=>e.activity==='context_input_included');assert.equal(events.length,count);
  for (const event of events) {
  const binding=JSON.parse(event.payload.descriptor).personaBinding;
  assert.equal(binding.personaId,persona);assert.equal(binding.agentId,agent.id);
  assert.equal(binding.externalContext.taskId,value.job.id);assert.equal(binding.externalContext.attemptId,value.job.attemptId);
  assert.equal(binding.externalContext.organizationSessionId,value.org.id);assert.equal(event.payload.authorization,'current-provider-check');
  }
}


test('independent: staged real producers close on partial failure and live-owner rejection', {skip:!source}, async t=>{
  const f=await fixture(t),workspace=join(f.dir,'managed'),events=join(f.dir,'process-events.jsonl'),wrapper=join(f.dir,'public-main-wrapper.py');
  // Instrument entry/exit around the unchanged public f6 main; no private imports.
  writeFileSync(wrapper,`import json,os,sys\nsys.path.insert(0,${JSON.stringify(resolve(source))})\nfrom persona_substrate.local_bridge import main\ndef record(kind):\n with open(${JSON.stringify(events)},'a',encoding='utf-8') as out: out.write(json.dumps({'kind':kind,'pid':os.getpid()})+'\\n')\nrecord('start')\ntry: main(sys.argv[1:])\nfinally: record('exit')\n`);
  for(const entry of f.catalogue.sources){entry.bridge.prefix_args=['-I','-B',wrapper];entry.bridge_identity=(await referenceHostSettings({hostId:f.hostId},entry.bridge)).identity;}f.save();
  const env={...process.env,PIDA_PERSONA_CATALOGUE:f.path,PIDA_SCHUMPETER_AUTH_URL:'http://127.0.0.1:1/v1/pida-authorization',PIDA_SCHUMPETER_AUTH_TOKEN:'independent-synthetic-policy-token-only'};
  const records=()=>readFileSync(events,'utf8').trim().split('\n').map(JSON.parse);
  const alive=pid=>{try{process.kill(pid,0);return true;}catch(error){assert.equal(error.code,'ESRCH');return false;}};
  async function launch(mode){
    const child=spawn(process.execPath,[join(root,'examples/schumpeter-host.mjs'),'--workspace',workspace,'--host-id',f.hostId,'--workspace-mode',mode,'--persona-module',join(root,'examples/vera-local-reference-catalogue.mjs')],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    let stderr='',stdout='';child.stderr.on('data',x=>stderr+=x);child.stdout.on('data',x=>stdout+=x);
    const closed=new Promise(r=>child.once('close',code=>r({code,stderr,stdout}))),timer=setTimeout(()=>child.kill(),12000);t.after(()=>child.kill());
    return {async ready(){await until(()=>stdout.includes('pida-host-ready'));},async done(){const result=await closed;clearTimeout(timer);return result;},async stop(){child.stdin.end();return this.done();}};
  }
  function tree(path,rel='',value={}){for(const e of readdirSync(path,{withFileTypes:true})){const key=rel+e.name;if(e.isDirectory())tree(join(path,e.name),key+'/',value);else value[key]=sha(readFileSync(join(path,e.name)));}return value;}
  const live=await launch('fresh');await live.ready();const originalPids=records().filter(r=>r.kind==='start').map(r=>r.pid);assert.equal(originalPids.length,2);assert.ok(originalPids.every(alive));
  const before=tree(workspace),loser=await(await launch('resume')).done();assert.equal(loser.code,1);assert.match(loser.stderr,/HOST_WORKSPACE_LOCKED/);assert.deepEqual(tree(workspace),before);
  let all=records(),competitors=all.filter(r=>r.kind==='start'&&!originalPids.includes(r.pid)).map(r=>r.pid);assert.equal(competitors.length,2);
  assert.ok(competitors.every(pid=>all.some(r=>r.pid===pid&&r.kind==='exit')&&!alive(pid)));assert.ok(originalPids.every(alive));
  assert.equal((await live.stop()).code,0);assert.ok(originalPids.every(pid=>!alive(pid)));
  const cutoff=records().length,b=f.catalogue.sources[1],database=join(b.bridge.store,'reference.sqlite3');writeFileSync(database,'synthetic-invalid-database');
  const stoppedTree=tree(workspace),partial=await(await launch('resume')).done();assert.equal(partial.code,1);assert.ok(!partial.stdout.includes('pida-host-ready'));assert.deepEqual(tree(workspace),stoppedTree);
  all=records().slice(cutoff);const partialPids=all.filter(r=>r.kind==='start').map(r=>r.pid);assert.equal(partialPids.length,2);assert.ok(partialPids.every(pid=>all.some(r=>r.pid===pid&&r.kind==='exit')&&!alive(pid)));
  console.log(JSON.stringify({probe:'staged-producer-lifecycle',live_owner_preserved:true,competing_children_closed:competitors.length,partial_failure_children_closed:partialPids.length,workspace_unchanged:true}));
});
