
test('independent: staged real producers close on partial failure and live-owner rejection', {skip:!source}, async t=>{
  const f=await fixture(t),workspace=join(f.dir,'managed'),events=join(f.dir,'process-events.jsonl'),wrapper=join(f.dir,'public-main-wrapper.py');
  // Instrument entry/exit around the unchanged public f6 main; no private imports.
  writeFileSync(wrapper,`import json,os,sys\nsys.path.insert(0,${JSON.stringify(resolve(source))})\nfrom persona_substrate.local_bridge import main\ndef record(kind):\n with open(${JSON.stringify(events)},'a',encoding='utf-8') as out: out.write(json.dumps({'kind':kind,'pid':os.getpid()})+'\\n')\nrecord('start')\ntry: main(sys.argv[1:])\nfinally: record('exit')\n`);
  for(const entry of f.catalogue.sources){entry.bridge.prefix_args=['-I','-B',wrapper];entry.bridge_identity=(await referenceHostSettings({hostId:f.hostId},entry.bridge)).identity;}f.save();
  const env={...process.env,PIDA_PERSONA_CATALOGUE:f.path,PIDA_SCHUMPETER_AUTH_URL:'http://127.0.0.1:1/v1/pida-authorization',PIDA_SCHUMPETER_AUTH_TOKEN:'independent-synthetic-policy-token-only'};
  const records=()=>readFileSync(events,'utf8').trim().split('\n').map(JSON.parse);
  const alive=pid=>{try{process.kill(pid,0);return true;}catch(error){assert.equal(error.code,'ESRCH');return false;}};
  async function launch(mode){
    const child=spawn(process.execPath,[join(root,'examples/schumpeter-host.mjs'),'--workspace',workspace,'--host-id',f.hostId,'--workspace-mode',mode,'--persona-module',join(root,'examples/vera-local-reference-catalogue.mjs')],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    let stderr='',stdout='';child.stderr.on('data',x=>stderr+=x);child.stdout.on('data',x=>stdout+=x);
    const closed=new Promise(r=>child.once('close',code=>r({code,stderr,stdout}))),timer=setTimeout(()=>child.kill(),12000);t.after(()=>child.kill());
    return {async ready(){await until(()=>stdout.includes('pida-host-ready'));},async done(){const result=await closed;clearTimeout(timer);return result;},async stop(){child.stdin.end();return this.done();}};
  }
  function tree(path,rel='',value={}){for(const e of readdirSync(path,{withFileTypes:true})){const key=rel+e.name;if(e.isDirectory())tree(join(path,e.name),key+'/',value);else value[key]=sha(readFileSync(join(path,e.name)));}return value;}
  const live=await launch('fresh');await live.ready();const originalPids=records().filter(r=>r.kind==='start').map(r=>r.pid);assert.equal(originalPids.length,2);assert.ok(originalPids.every(alive));
  const before=tree(workspace),loser=await(await launch('resume')).done();assert.equal(loser.code,1);assert.match(loser.stderr,/HOST_WORKSPACE_LOCKED/);assert.deepEqual(tree(workspace),before);
  let all=records(),competitors=all.filter(r=>r.kind==='start'&&!originalPids.includes(r.pid)).map(r=>r.pid);assert.equal(competitors.length,2);
  assert.ok(competitors.every(pid=>all.some(r=>r.pid===pid&&r.kind==='exit')&&!alive(pid)));assert.ok(originalPids.every(alive));
  assert.equal((await live.stop()).code,0);assert.ok(originalPids.every(pid=>!alive(pid)));
  const cutoff=records().length,b=f.catalogue.sources[1],database=join(b.bridge.store,'reference.sqlite3');writeFileSync(database,'synthetic-invalid-database');
  const stoppedTree=tree(workspace),partial=await(await launch('resume')).done();assert.equal(partial.code,1);assert.ok(!partial.stdout.includes('pida-host-ready'));assert.deepEqual(tree(workspace),stoppedTree);
  all=records().slice(cutoff);const partialPids=all.filter(r=>r.kind==='start').map(r=>r.pid);assert.equal(partialPids.length,2);assert.ok(partialPids.every(pid=>all.some(r=>r.pid===pid&&r.kind==='exit')&&!alive(pid)));
  console.log(JSON.stringify({probe:'staged-producer-lifecycle',live_owner_preserved:true,competing_children_closed:competitors.length,partial_failure_children_closed:partialPids.length,workspace_unchanged:true}));
});
