import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, writeFileSync, renameSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { fauxProvider, fauxAssistantMessage as answer } from '@earendil-works/pi-ai/providers/faux';
import { initWorkspace, readConfig, createWorkspace, workspaceEnvironment } from '../dist/workspace.js';
import { resolveExecutionPolicy } from '../dist/execution-policy.js';
import { PidaClient } from '../dist/client.js';
import { referenceHostSettings } from '../examples/vera-local-reference-persona.mjs';
import { hostPersonaIdentity, createHostPersona } from '../examples/vera-local-reference-catalogue.mjs';
const root = fileURLToPath(new URL('../', import.meta.url)), source = process.env.PIDA_TEST_LOCAL_REFERENCE;
const sha = x => createHash('sha256').update(x).digest('hex');
const principal = { id: 'local-user', permissions: ['pida:collaborate'] };
async function until(fn) { for(let n=0;n<500;n++){const v=await fn();if(v)return v;await delay(20);}assert.fail('TEST_TIMEOUT'); }
function python(executable, args) { const r=spawnSync(executable,args,{encoding:'utf8'});assert.equal(r.status,0,r.stderr+r.stdout);return r.stdout; }
async function fixture(t, expiredB=false) {
  const lock=JSON.parse(readFileSync(join(root,'fixtures/vera-dispatch/local-reference-source-lock.json')));
  for(const [p,h] of Object.entries(lock.runtime_files)) assert.equal(sha(readFileSync(join(source,p))),h);
  const dir=mkdtempSync(join(tmpdir(),'pdcat-')), hostId='catalogue-host', path=join(dir,'catalogue.json');
  const executable=python(process.env.PYTHON??'python',['-c','import sys;print(sys.executable)']).trim();
  const entry=join(resolve(source),'scripts/local_persona_bridge.py'), sources=[];
  for(const id of ['a','b']) {
    const config=join(dir,id+'.json'), store=join(dir,id+'-store');
    const value={schema_version:'vera-local-reference/0.1.0',principal:'provider:'+id,host_id:hostId,project_id:'schumpeter',memory_scope:['project:schumpeter'],
      persona:{persona_id:'persona:'+id,name:'Reference '+id,description:'SYNTHETIC_'+id.toUpperCase()+'_ONLY',source_refs:['document:catalogue-test']},grant_expires_at:expiredB&&id==='b'?100:Math.floor(Date.now()/1000)+3600};
    writeFileSync(config,JSON.stringify(value));
    if(expiredB&&id==='b') python(executable,['-I','-B','-c',`import sys;sys.path.insert(0,sys.argv[1]);from persona_substrate.local_bridge import initialize_store;initialize_store(sys.argv[2],sys.argv[3],clock=lambda:1)`,resolve(source),config,store]);
    else python(executable,['-I','-B',entry,'init','--config',config,'--store',store]);
    const bridge={executable,prefix_args:['-I','-B',entry],config,store}, selected=await referenceHostSettings({hostId},bridge);
    sources.push({id:'profile-'+id,label:'Reference '+id,profile_id:randomUUID(),persona_id:value.persona.persona_id,principal_ids:['local-user'],bridge,config_sha256:sha(readFileSync(config)),store_instance_id:selected.storeIdentity.store_instance_id,bridge_identity:selected.identity});
  }
  const catalogue={schema_version:'pida.persona-catalogue/1',host_id:hostId,sources};
  const save=()=>writeFileSync(path,JSON.stringify(catalogue));save();
  const previous=process.env.PIDA_PERSONA_CATALOGUE;process.env.PIDA_PERSONA_CATALOGUE=path;
  t.after(()=>{if(previous===undefined)delete process.env.PIDA_PERSONA_CATALOGUE;else process.env.PIDA_PERSONA_CATALOGUE=previous;});
  return {dir,path,hostId,executable,entry,catalogue,save};
}
async function embedded(t,f) {
  const workspace=join(f.dir,'workspace');initWorkspace(workspace);
  writeFileSync(join(workspace,'pida.config.json'),JSON.stringify({...readConfig(workspace),preset:'personal',tools:{directory:'tools',enabled:[]},workbench:{enabled:false},codingPacks:[],permissions:principal.permissions}));
  let app,bridge;
  const close=async()=>{if(app){await app.close();app.server.closeAllConnections();await new Promise(r=>app.server.close(r));app=undefined;}await bridge?.close();bridge=undefined;};
  const open=async()=>{
    bridge=await createHostPersona({hostId:f.hostId,personaIdentity:await hostPersonaIdentity({hostId:f.hostId}),async taskScope(taskId,agentId){
      const job=app.agents.getJob(taskId,principal);assert.equal(job.agentId,agentId);
      for(const org of app.agents.listOrganizations(principal)){const view=await app.agents.getOrganization(org.id,principal);
        if(view.tasks.some(t=>t.id===job.organizationTaskId&&t.agentId===agentId)&&view.attempts.some(a=>a.id===job.attemptId&&a.jobId===job.id))return {jobId:job.id,attemptId:job.attemptId,organizationTaskId:job.organizationTaskId,organizationSessionId:org.id};}
      throw Error('HOST_PERSONA_ORGANIZATION_REQUIRED');
    }});
    app=await createWorkspace(workspace,{personaSources:bridge.personaSources,executionPolicy:resolveExecutionPolicy('smoke/1')});
    app.server.listen(0,'127.0.0.1');await once(app.server,'listening');
    return new PidaClient({baseUrl:'http://127.0.0.1:'+app.server.address().port,token:()=>workspaceEnvironment(workspace).PIDA_API_TOKEN});
  };
  t.after(close);let client=await open();
  return {get app(){return app;},get client(){return client;},bridge,async restart(){await close();client=await open();},workspace};
}
async function run(f,agent,id,calls) {
  const runtime=await f.app.agents.getRuntime(agent.id,principal), faux=fauxProvider({tokensPerSecond:100000});
  faux.setResponses([context=>{calls.push({agent:agent.id,text:JSON.stringify(context)});return answer('Synthetic completion');}]);
  runtime.configureProvider(()=>({provider:faux.provider,modelId:faux.getModel().id}),{mode:'offline-catalogue-fixture',model:'faux'});
  const org=await f.client.createOrganization({requestId:id,goal:'Check the configured reference.',agentId:agent.id,participants:[agent.id],criterionIds:[]});
  const job=await until(async()=>{const list=await f.client.listAgentJobs(agent.id);return list.jobs.find(j=>j.organizationTaskId===org.rootTaskId&&!['queued','running'].includes(j.status));});
  return {job,org,bundle:await f.client.exportAgentJob(agent.id,job.id)};
}
function included(value,agent,persona,count=1){
  assert.equal(value.job.status,'completed',JSON.stringify(value.job));
  const events=value.bundle.events.filter(e=>e.activity==='context_input_included');assert.equal(events.length,count);
  for (const event of events) {
  const binding=JSON.parse(event.payload.descriptor).personaBinding;
  assert.equal(binding.personaId,persona);assert.equal(binding.agentId,agent.id);
  assert.equal(binding.externalContext.taskId,value.job.id);assert.equal(binding.externalContext.attemptId,value.job.attemptId);
  assert.equal(binding.externalContext.organizationSessionId,value.org.id);assert.equal(event.payload.authorization,'current-provider-check');
  }
}


import { existsSync } from 'node:fs';
import { hostname } from 'node:os';
test('independent: profile UUID must be a string with exact end boundary', {skip:!source}, async t=>{
  const f=await fixture(t),original=structuredClone(f.catalogue),outcomes=[];
  for(const value of [[original.sources[1].profile_id],original.sources[0].profile_id+'\n']) {
    f.catalogue.sources[0].profile_id=value;f.save();
    let accepted=false;try {await hostPersonaIdentity({hostId:f.hostId});accepted=true;}catch{}
    console.log(JSON.stringify({probe:'profile-id-type',kind:Array.isArray(value)?'array-of-other-profile-uuid':'uuid-final-newline',accepted}));
    outcomes.push(accepted);
  }
  assert.deepEqual(outcomes,[false,false]);
});
test('independent: same-source other-agent snapshots reject, native visibility cannot impersonate producer principal', {skip:!source}, async t=>{
  const f=await fixture(t), host={hostId:f.hostId};
  const bridge=await createHostPersona({...host,personaIdentity:await hostPersonaIdentity(host),taskScope:async taskId=>({jobId:taskId,attemptId:'attempt:independent',organizationTaskId:'orgtask:independent',organizationSessionId:'org:independent'})});t.after(()=>bridge.close());
  const contextA={principal,agentId:'agent:one',role:'review'},contextB={principal,agentId:'agent:two',role:'review'};
  const a=await bridge.personaSources[0].create(contextA),b=await bridge.personaSources[0].create(contextB);
  await assert.rejects(bridge.personaSources[0].create({...contextA,principal:{id:'provider:a'}}),/HOST_PERSONA_SOURCE_FORBIDDEN/);
  const request={...contextA,sessionId:'session:review',taskId:'job:review',runId:'run:review',signal:AbortSignal.timeout(4000)};
  const snapshot=await a.resolveContext(request);
  await assert.rejects(b.authorizeInput({...request,...contextB,snapshot,requestId:'request:review',attempt:1,inputDigest:'a'.repeat(64),fingerprintScope:'pi-logical-context/1',modelId:'faux',api:'faux'}),/HOST_PERSONA_SNAPSHOT_UNKNOWN/);
  const visible=await fixture(t);visible.catalogue.sources[0].principal_ids=['foreign-native'];visible.save();
  const app=await embedded(t,visible),overview=(await app.client.listAgents()).personaSources;
  assert.deepEqual(overview.sources.map(s=>s.id),['local','profile-b']);
  await assert.rejects(app.client.createAgent({name:'invisible',personaSourceId:'profile-a'}),{code:'AGENT_PERSONA_SOURCE_UNAVAILABLE'});
  const local=await app.client.createAgent({name:'explicit default'});assert.equal(local.personaSourceId,'local');
});

test('independent: producer startup failure on crash recovery preserves managed tree', {skip:!source}, async t=>{
  const f=await fixture(t), workspace=join(f.dir,'managed');
  const env={...process.env,PIDA_PERSONA_CATALOGUE:f.path,PIDA_SCHUMPETER_AUTH_URL:'http://127.0.0.1:1/v1/pida-authorization',PIDA_SCHUMPETER_AUTH_TOKEN:'independent-synthetic-policy-token-only'};
  async function launch(mode) {
    const child=spawn(process.execPath,[join(root,'examples/schumpeter-host.mjs'),'--workspace',workspace,'--host-id',f.hostId,'--workspace-mode',mode,'--persona-module',join(root,'examples/vera-local-reference-catalogue.mjs')],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});
    let stderr='',stdout='';child.stderr.on('data',x=>stderr+=x);child.stdout.on('data',x=>stdout+=x);
    const closed=new Promise(r=>child.once('close',code=>r({code,stderr,stdout})));
    const timer=setTimeout(()=>child.kill(),12000);t.after(()=>child.kill());
    return {child,closed,async stop(){child.stdin.end();const result=await closed;clearTimeout(timer);return result;},async done(){const result=await closed;clearTimeout(timer);return result;},async ready(){await until(()=>stdout.includes('pida-host-ready'));}};
  }
  const h=await launch('fresh');await h.ready();assert.equal((await h.stop()).code,0);
  const dead=spawnSync(process.execPath,['-e','process.exit(0)']);assert.equal(dead.status,0);
  assert.throws(()=>process.kill(dead.pid,0),{code:'ESRCH'});
  const runtimeLock=join(workspace,'.pida/runtime.lock');writeFileSync(runtimeLock,JSON.stringify({pid:dead.pid,host:hostname(),nonce:'synthetic-crash-lock'}));
  const b=f.catalogue.sources[1];writeFileSync(join(b.bridge.store,'reference.sqlite3'),'synthetic-corrupted-db');
  function tree(path,rel='',value={}){for(const e of readdirSync(path,{withFileTypes:true})){const key=rel+e.name;if(e.isDirectory())tree(join(path,e.name),key+'/',value);else value[key]=sha(readFileSync(join(path,e.name)));}return value;}
  const before=tree(workspace),failure=await(await launch('resume')).done(),after=tree(workspace);
  assert.equal(failure.code,1);assert.ok(!failure.stdout.includes('pida-host-ready'));
  console.log(JSON.stringify({probe:'failed-producer-resume',exit:failure.code,error:failure.stderr.trim(),runtime_lock_before:Object.hasOwn(before,'.pida/runtime.lock'),runtime_lock_after:existsSync(runtimeLock),changed_keys:[...new Set([...Object.keys(before),...Object.keys(after)])].filter(k=>before[k]!==after[k])}));
  assert.deepEqual(after,before);
});
