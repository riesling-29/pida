import hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).parent
def sha(b): return hashlib.sha256(b).hexdigest()
def parse(path):
    data = path.read_bytes()
    return json.loads(data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig'))
owner = 'D:/ChantaResearchGroup/pida-repository-profile-20261108'
frozen = subprocess.check_output(['git', '-C', owner, 'show', 'ff68457f7d032bfa0aa81badf27bdf4079cadc5e:docs/development/repository-catalogue-combination-evidence-20261108/probe.mjs'])
assert frozen == (root/'probe.mjs').read_bytes()
observations = {}
for os in ['windows', 'linux']:
    before = parse(root/f'{os}-before-verifier.json')
    after = parse(root/f'{os}-after-verifier.json')
    assert before == after and before['status'] == 'PASS'
    result = parse(root/os/'result.json')
    assert result['source_commit'] == before['source_commit']
    assert result['status'] == 'PASS'
    assert len(result['stock']['records']) == 2
    assert len(result['sdk']['records']) == 2
    assert len(result['sdk']['context_checks']) == 6
    assert all(c['own'] and not c['other'] for c in result['sdk']['context_checks'])
    assert [r['status'] for r in result['sdk']['records']] == ['failed', 'completed']
    observations[os] = {'full_tree_unchanged': True, 'verifier': after, 'result_sha256': sha((root/os/'result.json').read_bytes())}
(root/'independent-checks.json').write_text(json.dumps({'probe_frozen_bytes_match': True, 'observations': observations}, indent=2)+'\n', encoding='utf-8')
files = [{'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'evidence-index.json']
(root/'evidence-index.json').write_text(json.dumps({'source_commit': 'e9a1d31140bcff34e3c9ef0f82f4b3dbca0ddd68', 'author_probe_commit': 'ff68457f7d032bfa0aa81badf27bdf4079cadc5e', 'files': files}, indent=2)+'\n', encoding='utf-8')
for name in ['INDEPENDENT-COMBINATION-REVIEW.md', 'evidence-index.json']:
    print(name, sha((root/name).read_bytes()))
