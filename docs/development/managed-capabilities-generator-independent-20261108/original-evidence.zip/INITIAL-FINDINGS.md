# Initial managed capability generator review — fe30d74

Frozen source: fe30d74b783f41f16d9de2e3feb3b77cddc94f40.
Independent exact-source build and two author tests passed. Independent offline
synthetic full-manifest fixtures in probe-result.json isolate the new capability
semantic validation; fixture modules are inert text and never executed. Each
fixture has a newly calculated expected manifest pin, so these findings concern
release validation of a trusted candidate, not bypassing an existing pin.

P2: source provenance binding is incomplete. At
scripts/verify-runtime-distribution.mjs:23, only manifest.source_commit is passed
to the capability validator. A matching sidecar/top source fe30d74 plus
manifest.source.source_commit of forty 'a' characters passes. The contract
requires equality with verified source provenance as well. Repro label:
source-provenance-mismatch, exit0.

P2: declared modules need not have regular inventory entries. At
scripts/managed-host-capabilities.mjs:23–24, lstat checks the final path only.
A Windows internal directory junction pida/examples -> module-targets has a
valid inventoried link and targets, but the declared entrypoint/catalogue/helper
paths themselves have no regular manifest.files entries. Full verifier still
passes. Repro label: module-parent-junction, exit0. This violates the contract's
explicit regular inventory requirement, though the synthetic target bytes are
inside the verified tree; no current package compromise is claimed.

Additional consistency observation: a hardlinked sidecar passes while a
hardlinked module fails. The source contract explicitly calls for regular files;
the module helper additionally enforces nlink1. A corresponding sidecar check
would avoid a mutable alias. This is recorded separately from the two explicit
contract failures above.

Valid declaration and absent legacy declaration pass; nine malformed/oversized/
missing-module/altered-golden fixtures fail. Unknown fields, wrong source/ready,
profile ordering/digest and catalogue extras fail closed. Author supplied no
artifacts yet; their generation is held for this source review. Product source
was not edited and no provider/account/UI/live workspace was used.

Withdraw these findings when the exact corrected verifier rejects both
counterexamples while legitimate/legacy fixtures still pass; future source
changes require renewed comparison. Initial source result: FAIL in the two
stated capability-binding cases, pending correction.
