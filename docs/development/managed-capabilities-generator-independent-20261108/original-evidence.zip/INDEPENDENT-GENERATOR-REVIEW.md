# Independent managed capability generator review — 2026-11-08

Reviewer `/root/pida_windows_review`; source-only gate. Initial frozen source
`fe30d74b783f41f16d9de2e3feb3b77cddc94f40`; corrected reviewed source
`0f1b895d72d2f05a7c4fa21a2c9a5070aad71d8f`. Product code was read only. All
counterexamples use new synthetic fixture trees; no real runtime/account/model,
GUI, held workspace or deployed cache was used or modified.

## Initial findings and independently checked correction

Two P2 contract gaps were reproduced in the initial verifier, preserved in
`INITIAL-FINDINGS.md` and `probe-result.json`:

1. Sidecar and top-level manifest source agreed, but
   `manifest.source.source_commit` differed. Verification still returned PASS.
2. Declared modules were reached through an internal Windows parent junction.
   Their target bytes and link were inventoried, but the exact declared module
   paths had no regular inventory entries. Verification still returned PASS,
   contrary to the explicit capability contract.

These were correctly pinned synthetic candidate manifests to isolate semantic
validation. They did not bypass an existing approved hash, and do not establish
that any released artifact was compromised. A separate consistency observation
found a hardlinked root sidecar accepted while hardlinked modules were rejected.

In the correction, `scripts/verify-runtime-distribution.mjs:25` passes the full
already-verified manifest to `validateManagedCapabilityFiles`.
`scripts/managed-host-capabilities.mjs:29` requires both source identities to
match. Lines30–34 require exactly one regular hashed inventory entry for each
declared/required path, and a regular single-link size-bounded sidecar. Existing
regular-module checks retain their single-link requirement. This rejects both
original P2 reproductions and the sidecar-hardlink counterexample. Direct shape,
source, golden and module validation remains in place.

The generator's pre-inventory build validation intentionally has no manifest
argument yet; full inventory/provenance validation is performed by the separate
post-build verifier. Successful generation alone is not distribution acceptance.
The externally pinned manifest remains the trust root, not a detached sidecar.

## Independent execution and inspected source

- Exact corrected checkout build passed. The two author composite tests were
  independently rerun on Windows and WSL Linux, both2/2 PASS. No runtime source,
  examples or fixture content differs from the already accepted catalogue127611e
  closure; this is packaging/declaration/verification work.
- The unchanged independent15-fixture probe was rerun against corrected source:
  normal catalogue declaration and legacy absence pass; all13 malformed,
  source/profile/golden/size/missing-module/link/provenance cases reject.
  `fixed-probe-result.json` preserves exact commands' stdout/stderr and manifests.
  Module files in these fixtures are inert text and are never executed.
- Six additional independent order/closure cases pass in `ordering-result.json`.
  Wrong external pin fails `MANIFEST_HASH_MISMATCH`. Unpinned malformed sidecar,
  removed sidecar, changed module bytes and extra unlisted file all fail
  `RUNTIME_TREE_MISMATCH` before sidecar parsing/semantic validation. A valid
  policy-only declaration (`persona_catalogue:null`) passes with a new exact pin.
- Both declaration modes have exactly eight top-level keys; canonical equality
  constrains nested constants, catalogue fields and ordered complete policy
  objects. Values/digests come from the compiled execution-policy resolver and
  must equal the shipped golden. The generator writes the explicit sidecar
  before tree collection using exclusive creation; its script hash is recorded
  in manifest.packaging. Absent option preserves no-sidecar generation.
- An independent npm pack dry-run with isolated review cache confirms the exact
  `fixtures/execution-policy/profiles-v1.json` is included (1042bytes, mode0644).
  This is npm file-list evidence, not a generated runtime archive acceptance.
  See `npm-dry-run.json`.

The initial reviewer fixture attempted to mutate a frozen policy object and
stopped mid-construction. It was corrected with structuredClone; product code
and assertions were unchanged. `fixture-note.txt` records this; incomplete
temporary fixtures were left separate. All old and corrected results are kept.
Exact generator/package/verifier hashes are in `initial-source-hashes.json` and
`final-source-hashes.json`.

## Boundary and falsification

This review does not declare a new packaged ready2/policy/catalogue feature
available. Immutable Windows/Linux archive/source/module/sidecar identities,
normal extraction and actual packaged ready2/capability2, fresh/resume and
mismatch preservation remain the next artifact gate. Parent trusted capability
consumption, renderer restrictions, actual persona provisioning/grants, frozen
Python service and desktop UI remain separate. Legacy absence gives no ready2
declaration; it does not validate a live ready1 host by itself.

Synthetic supplied pins deliberately permit testing semantic guards; production
pins must come from the trusted parent inventory. This is not a guarantee against
arbitrary concurrent filesystem mutation or a replacement for whole-tree
verification. No broad fresh-install or full runtime suite claim is made.

Withdraw acceptance if either original counterexample passes again, unknown
closed fields/tuples become accepted, malformed advertised metadata falls back
to legacy availability, full-tree checks are bypassed, golden is absent from the
shipped package, or source/generator pins change. The result applies only to the
corrected source and inspected contract versions. Retaining existing ready1
artifacts is still the no-change deployment option.

**Conclusion: bounded PASS for corrected generator/verifier source0f1b895;
the initial two P2 findings are fixed, and immutable distribution acceptance
remains pending.**
