import assert from 'node:assert/strict';
import {cpSync,readFileSync,writeFileSync,mkdtempSync,readdirSync,lstatSync,unlinkSync} from 'node:fs';
import {join,relative,sep} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const evidence='D:/ChantaResearchGroup/pida-managed-capabilities-review-evidence-20261108',source='D:/ChantaResearchGroup/pida-review-distribution-20261107';
const fixture=JSON.parse(readFileSync(join(evidence,'fixed-probe-result.json'))).results.find(r=>r.label==='valid');
const sha=b=>createHash('sha256').update(b).digest('hex'),results=[];
function run(label,change,expected,repin=false,wrongPin=false){const root=mkdtempSync('D:/pmcr-1108/order-');cpSync(fixture.root,root,{recursive:true});change(root);let pin=fixture.manifestSha;
 if(repin){const files=[];function walk(d){for(const name of readdirSync(d)){const p=join(d,name),s=lstatSync(p),path=relative(root,p).split(sep).join('/');if(path==='manifest.json')continue;if(s.isDirectory())walk(p);else files.push({path,bytes:s.size,mode:s.mode&0o777,sha256:sha(readFileSync(p))});}}walk(root);files.sort((a,b)=>a.path<b.path?-1:1);const m={...fixture.manifest,files,file_count:files.length,tree_sha256:sha(JSON.stringify(files))};const bytes=JSON.stringify(m);writeFileSync(join(root,'manifest.json'),bytes);pin=sha(bytes);}
 const r=spawnSync(process.execPath,[join(source,'scripts/verify-runtime-distribution.mjs'),root,wrongPin?'0'.repeat(64):pin],{encoding:'utf8',windowsHide:true});if(expected==='PASS')assert.equal(r.status,0,r.stderr);else{assert.notEqual(r.status,0);assert.match(r.stderr,new RegExp(expected));}results.push({label,status:r.status,expected,stdout:r.stdout,stderr:r.stderr,root});}
run('wrong-external-pin',()=>{},'MANIFEST_HASH_MISMATCH',false,true);
run('malformed-unpinned-sidecar',r=>writeFileSync(join(r,'managed-host-capabilities.json'),'{not-json'),'RUNTIME_TREE_MISMATCH');
run('removed-declared-sidecar',r=>unlinkSync(join(r,'managed-host-capabilities.json')),'RUNTIME_TREE_MISMATCH');
run('changed-module-bytes',r=>writeFileSync(join(r,'pida/examples/schumpeter-host.mjs'),'changed'),'RUNTIME_TREE_MISMATCH');
run('extra-uninventoried-file',r=>writeFileSync(join(r,'extra.txt'),'extra'),'RUNTIME_TREE_MISMATCH');
run('policy-only-valid',r=>{const p=join(r,'managed-host-capabilities.json'),cap=JSON.parse(readFileSync(p));cap.persona_catalogue=null;writeFileSync(p,JSON.stringify(cap));},'PASS',true);
writeFileSync(join(evidence,'ordering-result.json'),JSON.stringify({status:'PASS',results},null,2)+'\n');console.log(JSON.stringify(results.map(({label,status,expected})=>({label,status,expected}))));
